// ==UserScript==
// @name         Hcaptcha Solver with Browser Trainer(Automatically solves Hcaptcha in browser)
// @namespace    Hcaptcha Solver
// @version      10.0.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       Md ubeadulla
// @match        https://*.hcaptcha.com/*hcaptcha-challenge*
// @match        https://*.hcaptcha.com/*checkbox*
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @run-at       document-start
// @connect      www.imageidentify.com
// @connect      https://cdnjs.cloudflare.com
// @connect      https://cdn.jsdelivr.net
// @connect      https://unpkg.com
// @connect      https://*.hcaptcha.com/*

/*
██╗░░██╗░█████╗░░█████╗░██████╗░████████╗░█████╗░██╗░░██╗░█████╗░  ░██████╗░█████╗░██╗░░░░░██╗░░░██╗███████╗██████╗░
██║░░██║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██║░░██║██╔══██╗  ██╔════╝██╔══██╗██║░░░░░██║░░░██║██╔════╝██╔══██╗
███████║██║░░╚═╝███████║██████╔╝░░░██║░░░██║░░╚═╝███████║███████║  ╚█████╗░██║░░██║██║░░░░░╚██╗░██╔╝█████╗░░██████╔╝
██╔══██║██║░░██╗██╔══██║██╔═══╝░░░░██║░░░██║░░██╗██╔══██║██╔══██║  ░╚═══██╗██║░░██║██║░░░░░░╚████╔╝░██╔══╝░░██╔══██╗
██║░░██║╚█████╔╝██║░░██║██║░░░░░░░░██║░░░╚█████╔╝██║░░██║██║░░██║  ██████╔╝╚█████╔╝███████╗░░╚██╔╝░░███████╗██║░░██║
╚═╝░░╚═╝░╚════╝░╚═╝░░╚═╝╚═╝░░░░░░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝  ╚═════╝░░╚════╝░╚══════╝░░░╚═╝░░░╚══════╝╚═╝░░╚═╝
*/
/** Note: This script is solely intended for the use of educational purposes only and not to abuse any website.
 * Sign Up using the referral links or consider a donation to the following addresses:
 ***************************************************************************************************
 * Faucets:                                                                                        *
 * Install the free cryporotator https://greasyfork.org/en/scripts/426599-free-cryptorotator       *
 * Or Sign up using the referral link and solve captchas to earn crypto (Do not abuse the websites)*
 * 1.) https://get-bitcoin.net/?ref=9230                                                           *
 * 2.) https://getdoge.io/?ref=34017                                                               *
 * 3.) https://r.adbtc.top/1771513                   *
 * 4.) https://cryptowin.io/ref/ubeadulla                                                          *
 * 5.) https://winalittle.fun/referral/02c7061877cec89e81a306303d36b77c                            *
 * 6.) https://faucetofbob.xyz/?ref=2121                                                           *
 * 7.) https://free-litecoin.com/login?referer=1035367                                             *
 * 8.) https://free-ethereum.io/?referer=742436                                                    *
 * 9.) https://litking.biz/signup?r=125431                                                         *
 * 10.) https://bitking.biz/signup?r=75339                                                         *
 ***************************************************************************************************
 * MicroWallets:                                                                                   *
 * 1.) FaucetPay: BTC: 1HeD2a11n8d9zBTaznNWfVxtw1dKuW2vT5                                          *
 *     LTC: MHpCuD3zAFEkeuhbgLbuZKcfdqMFkaLSem                                                     *
 *     BCH: bitcoincash:qp7ywra8h7lwatcuc7u65lv8x6rv5kn4sutrsnzrpx                                 *
 *     TRX: TLs3iQfXJs1rmUuG6pkLkUwcu32mFUwzgu                                                     *
 *     Doge: DPtBQG9GNTYHUFkjB2zYWYah4nCCogVAt9                                                    *                                             *
 * 2.) Direct BTC: 35HbfGfvbdctzY6tT4jcHXRx4zonBTnDuC                                              *
 ***************************************************************************************************
 * Cloud Mining Websites Just SignUp and earn passive income                                       *                                                                                       *
 * 1.) https://tronrex.online/r/86733                                                              *
 *                                                     *
 ***************************************************************************************************
 */

// ==/UserScript==
