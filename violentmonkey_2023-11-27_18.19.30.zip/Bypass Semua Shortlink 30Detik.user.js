// ==UserScript==
// @name       Bypass All Shortlinks 30Detik
// @name:id    Bypass Semua Shortlink 30Detik
// @name:ug    Bypass بارلىق قىسقا ئۇلىنىشلار
// @name:ar    تجاوز الجميع الروابط المختصرة
// @name:he    לַעֲקוֹף את כל קישורים קצרים
// @name:hi    सभी शॉर्टलिंक को बायपास करें
// @name:ja    バイパス 全て ショートリンク
// @name:zh-CN 旁路 全部 短链接
// @name:zh-TW 旁路 全部 短鏈接
// @name:pt-BR Bypass Todos Links curtos
// @name:fr-CA Bypass Tout Lien courts
// @name:fr    Bypass Tout Lien courts
// @name:ko    모든 짧은 링크 우회
// @name:th    บายพาส ทั้งหมด ลิงค์สั้น
// @name:bg    Заобикаляне на всички кратки връзки
// @name:ro    Bypass Toate Linkuri scurte
// @name:fi    Ohittaa Kaikki Lyhyet linkit
// @name:it    Bypassare Tutto Collegamenti brevi
// @name:el    Παράκαμψη Ολα Σύντομοι σύνδεσμοι
// @name:eo    Pretervojo Ĉiuj Mallongaj ligiloj
// @name:es    Bypass Todos Enlaces cortos
// @name:hu    Bypass Összes Rövid linkek
// @name:nb    Omgå Alle Kortlenker
// @name:sk    Obísť Všetky Krátke odkazy
// @name:sv    Förbigå alla kortlänkar
// @name:sr    Zaobići Sve Kratke veze
// @name:pl    Bypass Wszystkie Krótkie linki
// @name:nl    Bypass Alle Korte links
// @name:de    Bypass Alle Kurzlinks
// @name:da    Bypass Alle Shortlinks
// @name:cs    Bypass Všechno Krátké odkazy
// @name:uk    Обхід всі Короткі посилання
// @name:ru    Обход Все Короткие ссылки
// @name:tr    Bypass Tüm Kısa Linkler
// @name:vi    Bỏ qua Tất cả Các liên kết ngắn
// @namespace  Violentmonkey Scripts
// @version    22.2
// @author     Bloggerpemula
// @grant      none
// @run-at     document-end
// @description    Bypass All Shortlinks Sites Automatically Skips Annoying Link Shorteners and No Annoying Ads, Directly to Your Destination
// @description:id Bypass Semua Situs Shortlink Secara Otomatis Langsung ke Tujuan Tanpa Iklan yang Mengganggu
// @description:ug بارلىق قىسقا ئۇلىنىش تور بېكەتلىرىنى ئايلىنىپ ئۆتۈپ ، كىشىنى بىزار قىلىدىغان ئۇلىنىش قىسقارتقۇچنى ئاپتوماتىك ھالدا مەنزىلىڭىزگە ئاتلاڭ.
// @description:ar تجاوز جميع مواقع الروابط المختصرة يتخطى تلقائيًا أدوات تقصير الروابط المزعجة ، مباشرة إلى وجهتك
// @description:he עוקף את כל אתרי הקישורים הקצרים מדלג אוטומטית על מקצרי קישורים מעצבנים, ישירות ליעד שלך
// @description:hi सभी शॉर्टलिंक साइटों को बायपास करें, सीधे आपके गंतव्य पर कष्टप्रद लिंक शॉर्टनर को छोड़ दें
// @description:ja すべてのショートリンクサイトをバイパスすると、迷惑なリンクショートナーが自動的にスキップされ、宛先に直接送信されます
// @description:fr Contourner tous les sites de liens courts saute automatiquement les raccourcisseurs de liens gênants, directement vers votre destination
// @description:ko 모든 짧은 링크 사이트 우회는 성가신 링크 단축기를 자동으로 건너뛰고 목적지로 직접 이동합니다.
// @description:th ข้ามไซต์ลิงค์สั้นทั้งหมดข้ามลิงค์ย่อที่น่ารำคาญโดยอัตโนมัติไปยังปลายทางของคุณ
// @description:bg Заобикаляне на всички сайтове с кратки връзки Автоматично пропуска досадните средства за съкращаване на връзки, директно до вашата дестинация
// @description:ro Omite toate site-urile cu linkuri scurte Omite automat elementele de scurtare a linkurilor enervante, direct către destinația ta
// @description:fi Ohita kaikki lyhytlinkkisivustot ohittaa automaattisesti ärsyttävät linkinlyhennykset suoraan määränpäähäsi
// @description:it Ignora tutti i siti di collegamenti brevi Salta automaticamente i fastidiosi accorciatori di collegamenti, direttamente alla tua destinazione
// @description:el Παράκαμψη όλων των τοποθεσιών σύντομων συνδέσμων Παρακάμπτει αυτόματα τα ενοχλητικά προγράμματα συντόμευσης συνδέσμων, απευθείας στον προορισμό σας
// @description:eo Preterpasi Ĉiuj Mallongaj Ligiloj-Ejoj Aŭtomate Saltas ĝenajn Ligilojn, Rekte al Via Celo
// @description:es Omitir todos los sitios de enlaces cortos omite automáticamente los acortadores de enlaces molestos, directamente a su destino
// @description:hu Az összes rövid hivatkozási webhely megkerülése automatikusan átugorja a bosszantó linkrövidítőket, közvetlenül az úticélra
// @description:nb Omgå alle korte lenker Nettsteder hopper automatisk over irriterende lenkeforkortere, direkte til destinasjonen din
// @description:sk Obíďte všetky stránky s krátkymi odkazmi, ktoré automaticky preskočia otravné skracovače odkazov priamo do vášho cieľa
// @description:sv Förbi alla korta länkar webbplatser hoppar automatiskt över irriterande länkförkortare, direkt till din destination
// @description:sr Zaobići sve stranice s kratkim vezama automatski preskače dosadne skraćivače veza, izravno na vaše odredište
// @description:pl Pomijaj wszystkie strony z krótkimi linkami automatycznie pomija irytujące skracacze linków, bezpośrednio do miejsca docelowego
// @description:nl Omzeil alle sites met korte links en slaat automatisch vervelende linkverkorters over, rechtstreeks naar uw bestemming
// @description:de Alle Short-Links-Sites umgehen Überspringt automatisch lästige Link-Shortener direkt zu Ihrem Ziel
// @description:da Omgå alle korte links-websteder springer automatisk irriterende linkforkortere over, direkte til din destination
// @description:cs Obejít všechny stránky s krátkými odkazy Automaticky přeskakuje otravné zkracovače odkazů přímo do vašeho cíle
// @description:uk Обійти всі сайти з короткими посиланнями. Автоматично пропускає дратівливі скорочення посилань безпосередньо до вашого пункту призначення
// @description:ru Обход всех сайтов с короткими ссылками автоматически пропускает надоедливые сокращатели ссылок, прямо к месту назначения
// @description:tr Tüm Kısa Linkleri Atla Siteler Can sıkıcı Link Kısaltıcıları Otomatik Olarak Atlar, Doğrudan Hedefinize
// @description:vi Bỏ qua tất cả các trang web liên kết ngắn tự động bỏ qua các trang web liên kết gây phiền nhiễu, trực tiếp đến đích của bạn
// @description:zh-cn 绕过所有短链接网站自动跳过烦人的链接缩短器，直接到您的目的地
// @description:zh-tw 繞過所有短鏈接網站自動跳過煩人的鏈接縮短器，直接到您的目的地
// @description:pt-br Ignorar todos os sites de links curtos ignora automaticamente encurtadores de links irritantes, diretamente para o seu destino
// @description:fr-ca Contourner tous les sites de liens courts saute automatiquement les raccourcisseurs de liens gênants, directement vers votre destination
// @include /^(https?:\/\/)(tmearn|jobklic|additionalgamer|uformations|makemoneywithurl|rifurl|shrinkearn|esenr|adsforfaucets|skip-url|pennbookcenter|publicananker|mikl4forex|michaelemad|miklpro|zirof|forex-golds|nawahi1|mmo1s|mosqam|semawur|forex-trnd|hoshilink|bit-url|cuts-url|coinlyhub|popimed|phoenixshorts|rayusmedya|enburl|madar-24|katflys|shortenbuddy|kiemlua|kekolink|smoner|djbhojpurisongs|coinadfly|shornet|clixshort|earnflies|urlty|sakastau|adsmoker|claimclicks|doctor-groups|earnwithshortlink|bitzite|link1s|diadiemcheckin|tudiendanhngon|chooyomi|staaker|lucidcam|coinsparty|forexlap|forexmab|linkjust|forex-articles|ponselharian|liinkat|thegoneapp|alocd|mobi2c|0x-bit|studyuo|hookeaudio|fc-lc|expertvn|markipli|downphanmem|kingsleynyc|theicongenerator|healthy4pepole|kiktu|1bitspace|healdad|marharo|ez4mods|try2link|ex-foary|discordserv|softechbharat|adcorto|movie4i|shopdorod|bitcoin-indo|crypto-news-hub|blogginglass|1shorten|amazingdarpon|lensabicara|tieutietkiem|bittalky|urlily|bablyfeed|crypto4tun|coin-free|dash-free|usdshort|coinsurl|cafenau|techacode|ls2earn|sevenjournals|mercedesellington|7misr4day|sama-pro|samaa-pro|imageresizertool|techrfour|ez4short|topnewsnew|gawishpro|ad-mezo|dz4link|skincarie|okrzone|dogemate|coinsearns|informaxonline|gaminplay|proviralhost|guardbolts|short-zero|infinitycoupon|mfk-shorter|donnaleehunt|gamalk-sehetk|adsafelink|cbshort|haymod|ltc-free|nulledsafe|dreamcheeky|cutpaid|fidlarmusic|rodjulian|anhdep24|shortlink.earnmotivation|short.clickscoin|money.alyoumeg|sl.claimfreebits|sl-1.btcbunch|sl-2.btcbunch|sl-3.btcbunch|redlifek|btcwalk|bdtechh|apk.miuiku|apk.sekilastekno|bitefaucet|playgotoken|techrayzer|shorteet|bitlya|ecwizon|oncehelp|yummy-reciepes|loptelink|2shrt|charexempire|coindoog|shotzon|novelsapps|webhostingpost|nightfallnews|tirailangit|intercelestial|tribuntekno|vhorizads|bestcash2020|7nything|hoxiin|linkat4u|fooot-map|bellurl|abcshort|checkscoin|llinkon|priefy|dz-linkk|donia-tech|donia2tech|donia2link|short1s|up-urls|shrinkmoney|doodshort|paid4link|d.bawabatak|newlycrypto|kienthucrangmieng|wiki-topia|wingifta|aljoodm98|newworldnew|short-jambo|mazen-ve|bclikeqt|youssefsayed|fx4vip|shortzon|get4links|crickblaze|nostralink|clkmein|101desire|memangbau|hosting4lifetime|btcpany|bebodybuilder|mesho-link|eda-ah|newsharsh|oxolink|examkhata|linksht|note1s|adclickersbot)(\.com)(\/.*)/
// @include /^(https?:\/\/)(.+)?(zolomix|cararegistrasi|5golink|birdurls|urlfiles|snkra|artiskini|sh2rt|byboe|medcpu|nousdecor|restorbio|bdnewsx|upshrink|gifans|jardima|jobswd|dogeearn|gkqnaexam|imperialstudy|ovlinks|imagenesderopaparaperros|w4earn|url2link|yofaurls|shortique|digiromotion|blog-forall|techymedies|gamelopte|adshort-url|cgyojna|riadcrypto|riadblog|askpaccosi|linktrims|gets4link|urlshortify|visflakes|apk4do|dineroshare|oyunzak|elwatanelyoum|ledifha|claimfey|htshort|shrinkito|panylink|kriptoryum|sisgy|wrbloggers|encyclopedia-24|tokenoto)(\.com)(\/.*)/
// @include /^(https?:\/\/)(sehati|boxlink|zoxlink|moxlink|foxlink|forex-lab|watchdoge|arenaboard|ccsl|xz2|mshort|shrinkpay|adsgo|gainprofit|foofly|adnit|bestshort|shon|crypto-faucet|short-cash2|toptechtalk|foodyrecipe|cutearn|infinityfreescripts|st4ch|wizzly|saqercoin|cryptoon|porofly|morofly|zorofly|worofly|nooz|tooz|mgnet|crypteen|dogeen|coocly|doodly|fauceteen|k-sport|z-sport|n-sport|adcorto|speedynews|tecboy|cutdl|marocclickers|9bitcoin|gameen|fameen|yameen|phoenixs|girlporo|girlmoro|girlzoro|girlworo|cryptocoinearn|shorte|potoly|motoly|kotoly|ashort1a|zololink|blog.crypto-faucet|stores.filmyzilla-in|links.doctorcoin|cbs.trxking||temp-late|template-zone|coinzat|top-blog|kora-yalla|swzz|acortame|bitsyield|nivaprofit|alghtas|wizly|kishoter|horanews|linkfort|a1link|likn|short2fly|java-script|nabits|playstore|welovecrypto|worldappsstore|shortplus|post.nites-tv|3vw|html-script|mrsaifi|st.kleaco|playlink)(\.xyz)(\/.*)/
// @include /^(https?:\/\/)(.+)?(insuranceblog|insurance-space|bcdshort|insurglobal|lootlinks|adinsurance|urbharat|claimercorner|egfly|ajifly|urlmoney|dexlink|cekip|crypto-blog|megano-coin|doctorcoin)(\.xyz)(\/.*)/
// @include /^(https?:\/\/)(bigb0ss|neonlink|techydino|illink|digitalnaz|world-trips|cryptourl|yoshare|forex-gold|allcryptoz|topcryptoz|techtrickonline|uniqueten|7apple|zurls|ovavibe|ccurl|luckydice|link1s|bitcomarket|url.namaidani|crewbase|crewus|shinchu|shinbhu|thumb8|thumb9|karimunbits|linkrex|cryptowidgets|dogeclick|adskip)(\.net)(\/.*)/
// @include /^(https?:\/\/)(.+)?(100count|fire-link|owllink|mozlink|ultraten|cryptosats|rocklinks|celinks|gazianteppetektemizleme|jiotech|jemari)(\.net)(\/.*)/
// @include /^(https?:\/\/)(tnlink|jrlinks|shortzzy|coincity|techmart4u|9bitco|qualitystudymaterial|adoco|cuturl|missionhight|wpking|foodma|zagl|ls2earn|streamshort|cslink|coinbaze|blog.earn4fun|blog.earn2fly|shareus|referus|megafly|megaurl|csd.xmod|cutp|sureshjonna|earnmoj|riadshot|urlmoney|cplink|cryptomonitor|technoflip|linkshortify|studyranks|htlinks|techlearningtube|manthans|urlfly|linkocean)(\.in)(\/.*)/
// @include /^(https?:\/\/)(.+)?(cashurl|linkad|bitcoinly|crazyblog|zolomix|technologylover|earnfort|spidermods|expertlinks|linksfire|largestpanel|linkres|rsrlink|linkstream)(\.in)(\/.*)?/
// @include /^(https?:\/\/)(aylink|linkszia|claimsatoshi|mynewsmedia|bitshort|gtlink|earnload|adfloz|linksly|droplink|123link|go.leolink|techload|linksfy|adshorti)(\.co)(\/.*)/
// @include /^(https?:\/\/)(.+)?(takez|linksfire)(\.co)(\/.*)/
// @include /^(https?:\/\/)(ctbl|skyurl|girls-like|adsoro|gobits|zoss|shrinke|tlin|health-and|short.croclix|stfly|adbull|cutx|clicksfly|youshort|wildblog)(\.me)(\/.*)/
// @include /^(https?:\/\/)(.+)?(theconomy|adcorto|adsurfing|richlink|wildlinks)(\.me)(\/.*)/
// @include /^(https?:\/\/)(sitr|palpodcast|safelink|zipcrypto|cutgo|cutbits|shorthero|flylink|earncoin|downfile|savelink|linkshortify|url.coinfree|zo.coin-city|promo-visits)(\.site)(\/.*)/
// @include /^(https?:\/\/)(.+)?(bshopme|cekip|kolotoken)(\.site)(\/.*)/
// @include /^(https?:\/\/)(earnme|sanoybonito|forexat|automotur|1ist|kooza|atlai|claimbitco|1link|zentum|9btc)(\.club)(\/.*)/
// @include /^(https?:\/\/)(.+)?(mcrypto|usanewstoday)(\.club)(\/.*)/
// @include /^(https?:\/\/)(technicalramno1|paid4|freedoge|yousm|shortzzy|coinpayz|tr|zipfy|yocto|clk.dti|besturl|zuba|earnmy)(\.link)(\/.*)/
// @include /^(https?:\/\/)(.+)?(vshort|stex)(\.link)(\/.*)/
// @include /^(https?:\/\/)(shurt|shortit|adsy|bitlinks|clik|playstore)(\.pw)(\/.*)/
// @include /^(https?:\/\/)(.+)?(adsee|prz)(\.pw)(\/.*)/
// @include /^(https?:\/\/)(crypto-adria|bloogerspoot|vsbl)(\.ga)(\/.*)/
// @include /^(https?:\/\/)(url.faucet77|bloogerspoot|ashort2a-bro)(\.tk)(\/.*)/
// @include /^(https?:\/\/)(linkstom|techycontent|techfort|bloogerspoot|urlchanger)(\.ml)(\/.*)/
// @include /^(https?:\/\/)(onimports|link.encurtaon)(\.com\.br)(\/.*)/
// @include /^(https?:\/\/)(didhafairus|mycut|exee|onlineteori|go.safeadlink|sealink|onlineteori)(\.my\.id)(\/.*)/
// @include /^(https?:\/\/)(coinshub|myhealths|kiiw|passgen|wordcounter|shrink)(\.icu)(\/.*)/
// @include /^(https?:\/\/)(luckybits|newforex|uebnews|wplink|nbyts|wealthystyle|ls2earn|happy-living|earn-cash|yourtechnology|bell.healthyguy|network-earn)(\.online)(\/.*)/
// @include /^(https?:\/\/)(.+)?(adslinkfly)(\.online)(\/.*)/
// @include /^(https?:\/\/)(exey|ezlinks|techmody|ouo|ex-e|upfiles|short.goldenfaucet|saly)(\.io)(\/.*)/
// @include /^(https?:\/\/)(.+)?(linkfly|usalink)(\.io)(\/.*)/
// @include /^(https?:\/\/)(zshort|earnfree|claimcrypto|cashearn|1ink|linkpay|moneylink|cryptoflare)(\.cc)(\/.*)/
// @include /^(https?:\/\/)(.+)?(rota|netfile)(\.cc)(\/.*)/
// @include /^(https?:\/\/)(cryptoad|urlpay|wikile)(\.org)(\/.*)/
// @include /^(https?:\/\/)(.+)?(fullreviews|freebcc|medipost|shrinkurl)(\.org)(\/.*)/
// @include /^(https?:\/\/)(linkmit|zcpa|jameeltips|mitly)(\.us)(\/.*)/
// @include /^(https?:\/\/)(.+)?(yalla-shoot-now|forexeen)(\.us)(\/.*)/
// @include /^(https?:\/\/)(mixespecialidades|noweconomy|deportealdia|adshort|ay|pngit)(\.live)(\/.*)/
// @include /^(https?:\/\/)(.+)?(hostingviral|linksos)(\.live)(\/.*)/
// @include /^(https?:\/\/)(earnads|genpassword|shrlink|coxsbd96|mshort)(\.top)(\/.*)/
// @include /^(https?:\/\/)(profitlink|zagl|scratch247|siyn|portablesusb|children-learningreading|azmath|machicon-akihabara|cooklike)(\.info)(\/.*)/
// @include /^(https?:\/\/)(hcsbtc|alertcrypto|aboutprofit|faucetcrypto)(\.eu)(\/.*)/
// @include /^(https?:\/\/)(freebitcoin|freelitecoin)(\.vip)(\/.*)/
// @include /^(https?:\/\/)(iir|tei)(\.ai)(\/.*)/
// @include /^(https?:\/\/)(aii|clk)(\.sh)(\/.*)/
// @include /^(https?:\/\/)(nukl|clk)(\.ink)(\/.*)/
// @include /^(https?:\/\/)(.+)?(i8l)(\.ink)(\/.*)/
// @include /^(https?:\/\/)(brixarena)(\.tech)(\/.*)/
// @include /^(https?:\/\/)(kiw|redir.123file)(\.li)(\/.*)/
// @include /^(https?:\/\/)(azsoft|tronex|zonearn)(\.biz)(\/.*)/
// @include /^(https?:\/\/)(.+)?(cryptolatest|trangchu)(\.news)(\/.*)/
// @include /^(https?:\/\/)(cryptoads|adshort|1bit|paylinks|2the|careerhunter)(\.space)(\/.*)/
// @include /^(https?:\/\/)(.+)?(cryptolink|adz7short)(\.space)(\/.*)/
// @include /^(https?:\/\/)(cryptoaffiliates|android-mody)(\.store)(\/.*)/
// @include /^(https?:\/\/)(makeeasybtc|petslots|softindex|short.toptap)(\.website)(\/.*)/
// @include /^(https?:\/\/)(dogecoin|icut)(\.click)(\/.*)/
// @include /^(https?:\/\/)(.+)?(shortlinks|easysl)(\.click)(\/.*)/
// @include /^(https?:\/\/)(.+)?(hamody)(\.pro)(\/.*)/
// @include /^(https?:\/\/)(up-load|t2l)(\.one)(\/.*)/
// @include /^(https?:\/\/)(easyfaucet|sh.feyorra|fey.feyorra|go.lokak|earnbitcoin)(\.fun)(\/.*)/
// @include /^(https?:\/\/)(.+)?(madshiba)(\.fun)(\/.*)/
// @include /^(https?:\/\/)(doge-mining|gamefaucet|doge-mining|linkati)(\.win)(\/.*)/
// @include /^(https?:\/\/)(url\.)?(acefaucet|namaidani|magmint)(\.com)(\/.*)/
// @include /^(https?:\/\/)(cool-time|movies|anime|tech)(\.dutchycorp\.space)(\/.*)/
// @include /^https:\/\/clickscoin\.com\/(shortccsl|short)/
// @include /^https:\/\/cryptofans\.club\/(short|next|other|step)/
// @exclude /^https:\/\/claimclicks\.com\/(btc|ltc|doge|trx|faucetlist|ptclist)/
// @exclude /^https:\/\/claimercorner\.xyz\/(claimer\/dashboard|claimer\/advertise|claimer\/ptc|claimer\/deposit|claimer\/transfer|claimer\/tasks|claimer\/offerwall|claimer\/profile|claimer\/auto|claimer\/mining|claimer\/wheel|claimer\/login)/
// @exclude /^https:\/\/cryptosats\.net\/(cryptosats\/dashboard|cryptosats\/advertise|cryptosats\/ptc|cryptosats\/deposit|cryptosats\/transfer|cryptosats\/tasks|cryptosats\/offerwall|cryptosats\/profile|cryptosats\/auto|cryptosats\/mining|cryptosats\/wheel|cryptosats\/login)/
// @exclude /^https:\/\/easyfaucet\.fun\/(dashboard|advertise|ptc|deposit|transfer|tasks|offerwall|profile|auto|mining|dice|lottery|faucet|login)/
// @exclude    *://coinsearns.com/
// @exclude    *://luckydice.net/
// @exclude    *://fc.madshiba.fun/*
// @match      *://dutchycorp.space/s*/*
// @match      *://dutchycorp.ovh/s*/*
// @match      *://*/recaptcha/*
// @match      *://coin.mg/*
// @match      *://shorts.lu/*
// @match      *://tny.so/*
// @match      *://ouo.press/*
// @match      *://ouo.today/*
// @match      *://za.uy/*
// @match      *://za.gl/*
// @match      *://2ad.ir/*
// @match      *://prx.ee/*
// @match      *://goads.ly/*
// @match      *://kimo.ma/*
// @match      *://c2g.at/*
// @match      *://fcc.lc/*
// @match      *://clk.asia/*
// @match      *://mdn.rest/*
// @match      *://*.mdn.world/*
// @match      *://anonym.ninja/*
// @match      *://faucet.work/*
// @match      *://median.uno/*
// @match      *://romania.bz/*
// @match      *://pingit.im/*
// @match      *://nail.edu.pl/*
// @match      *://antonimos.de/*
// @match      *://carapedi.id/*
// @match      *://ashorturl.uk/*
// @match      *://bildirim.eu/ph/*
// @match      *://nex-url.cyou/*
// @match      *://arbweb.info/sl/*
// @match      *://cryptofuns.ru/*
// @match      *://phongcachsao.vn/*
// @match      *://faucethub.ly/sh/*
// @match      *://*.techgeek.digital/*
// @match      *://supersites.xyz/verifysl*
// @match      *://app.handydecor.com.vn/*
// @match      *://sohexo.org/kisalink/*
// @match      *://toptap.website/short/*
// @match      *://*.adcortoltda.agency/*
// @match      *://hitbits.io/slk/*
// @match      *://getitall.top/f/*
// @match      *://pentafaucet.com/f/*
// @match      *://starfaucet.net/sl/*
// @match      *://adcrypto.co/claim/*
// @match      *://faucet.gold/BTC/?step*
// @match      *://faucet.gold/ETH/?step*
// @match      *://konstantinova.net/verify/*
// @match      *://*.softairbay.com/shortSAB/*
// @match      *://faucetcrypto.com/claim/step/*
// @match      *://cryptorotator.website/sh_live/*
// @match      *://*.reddcoineveryday.com/short/*
// @match      *://*.google.com/url?sa=t&rct=j&q*
// @match      *://cryptonetos.ru/page/redirect*
// @match      *://speedsatoshi.com/lootlinks/*
// @match      *://faucetpay.nurul-huda.or.id/*
// @match      *://wp.womenhaircolors.review/*
// @match      *://cryptotyphoon.com/short/*
// ==/UserScript==
// ==========================================================================================================================================
//                                 PLEASE DON'T REMOVE OR CHANGE MY BLOG, THANKS
//                         My Blog is Important to Track New Shortlinks , Broken Bypass etc...
// Thanks so much to @JustOlaf , @Konf , @hacker09 for Helping me , make my script even better , and for All who has contributed via Feedback.
// ===========================================================================================================================================
(function() {
    'use strict';
    const bp = query => document.querySelector(query);
    const elementExists = query => bp(query) !== null;
    const domainCheck = domains => new RegExp(domains).test(location.host)
    function click(query) {bp(query).click()}
    function submit(query) {bp(query).submit()}
    function clickIfElementExists(query, timeInSec = 1, funcName = 'setTimeout') {if (elementExists(query)) {window[funcName](function() {click(query);}, timeInSec * 1000);}}
    function recaptchaInterval(query, act = 'submit', timeInSec = 0.5) {if (elementExists(query)) {const timer = setInterval(function() {if (window.grecaptcha && !!window.grecaptcha.getResponse()) {bp(query)[act](); clearInterval(timer);}}, timeInSec * 1000);}}
    function recaptchaIntervalclick(query, act = 'click', timeInSec = 0.5) {if (elementExists(query)) {const timer = setInterval(function() {if (window.grecaptcha && !!window.grecaptcha.getResponse()) {bp(query)[act](); clearInterval(timer);}}, timeInSec * 1000);}}
    function redirect(url, blog = true) {location = blog ? 'https://faucetpay.nurul-huda.or.id/?url=' + url : url;}
    function BypassedByBloggerPemula(re_domain, data, blog) { if (!re_domain.test(location.host)) return
        if (typeof data === 'function') return data()
        if (Array.isArray(data)) data = {'/': data}
        const [key, value] = data[location.pathname]
        if (typeof key === 'object' && key.test(location.search)) return redirect(value + RegExp.$1, blog)
        const searchParams = new URLSearchParams(location.search);
        if (searchParams.has(key)) redirect(value + searchParams.get(key), blog)}
    function meta(href) {document.head.appendChild(Object.assign(document.createElement('meta'), { name: 'referrer', content: 'origin'}));
        Object.assign(document.createElement('a'), {href}).click();}
    function waitForElm(query, callback) {setTimeout(function() {if (elementExists(query)) {callback(bp(query))} else {waitForElm(query, callback)}}, 1000)}
    function next(short_id) {fetch('https://sl.lindernman.xyz/s/next', {"headers": {"content-type": "application/json;charset=UTF-8"},
            "body": JSON.stringify({short_id}),
            "method": "POST"})
            .then(res => res.text())
            .then(console.log)}
    function complete(short_id) {fetch('https://sl.lindernman.xyz/s/complete', {"headers": {"content-type": "application/json;charset=UTF-8"},
             "body": JSON.stringify({short_id}),
             "method": "POST"})
            .then(res => res.text())
            .then(data => {redirect(JSON.parse(data))})}
    function notify(txt, width = 850) { const m = document.createElement('div');
             m.style.padding = '10px'; m.style.zIndex = 99999999; m.style.position = 'fixed'; m.style.boxSizing = 'border-box';
             m.style.width = `${width}px`; m.style.top = '130px'; m.style.left = `${innerWidth / 2 - width / 2}px`; m.style.font = 'normal bold 20px sans-serif';
             m.style.backgroundColor = 'white'; m.innerText = txt; document.body.appendChild(m);}
    if(location.host === 'faucetpay.nurul-huda.or.id'){ } else { const listhide = document.querySelectorAll('#frame,#iframe,#particles-js,#canvas,.banner-inner,.floawing-banner,.floating-banner,.vanta-canvas,.particles-js-canvas-el,#s65c,#ofc9,#overlay,#footerads,.oulcsy,.blog-item,.sticky-bottom,.separator,html body iframe,html iframe,#cookie-pop,.vmyor,.tnjmvneldp')
    for (const element of listhide) {element.remove()}}
    if(['dutchycorp.space','dutchycorp.ovh'].includes(window.location.hostname) > -1){ var ticker = setInterval(function(){ try{window.grecaptcha.execute(); clearInterval(ticker);} catch(e) {}},2000);}else {}
    // ============================================
    // Captcha Mode
    // ============================================
    recaptchaInterval('#userForm')
    recaptchaInterval('#ShortLinkId')
    recaptchaInterval('#file-captcha')
    recaptchaInterval('#lview > form')
    recaptchaInterval('#link-view')
    recaptchaInterval('form.text-center')
    recaptchaInterval('#wpsafelink-landing')
    recaptchaInterval('.col-12 > form:nth-child(1)')
    recaptchaInterval('.contenido > form:nth-child(2)')
    recaptchaInterval('#showMe > center:nth-child(4) > form:nth-child(1)')
    recaptchaInterval('#showMe > center:nth-child(1) > center:nth-child(4) > form:nth-child(1)')
    recaptchaInterval('#adb-not-enabled > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(5) > form:nth-child(1)')
    recaptchaIntervalclick('.m-2.btn-captcha.btn-outline-primary.btn')
    recaptchaIntervalclick('.m-2.btn-captcha.btn-outline-primary.btn')
    recaptchaIntervalclick('button#continue.btn.btn-primary.btn-captcha')
    recaptchaIntervalclick('#yuidea-btn-before.yu-btn.yu-blue')
    recaptchaIntervalclick('#yuidea-btn-after.yu-blue.yu-btn')
    // ============================================
    // SetTimeout Mode
    // ============================================
    clickIfElementExists('.recaptcha-checkbox-border', 3)
    clickIfElementExists('button#btn6.yu-btn.yu-go', 3)
    clickIfElementExists('.mb-3 > .btn-primary.btn', 3)
    clickIfElementExists('.yu-blue.yu-btn', 3)
    clickIfElementExists('.fTk7vd > a:nth-child(1)', 3)
    clickIfElementExists('#links > a:nth-child(2)', 3)
    clickIfElementExists('button#showTimerText.btn.btn-accent', 3)
    clickIfElementExists('#wpsafelinkhuman > img:nth-child(1)', 3)
    clickIfElementExists('div.box-main:nth-child(2) > div:nth-child(4) > a:nth-child(1)', 3)
    clickIfElementExists('button#btn6.g-recaptcha.btn.btn-primary', 3)
    clickIfElementExists('button#btn6.btn.btn-outline-primary.btn-captcha.m-2', 3)
    clickIfElementExists('button#submit-button.btn.btn-primary', 3)
    clickIfElementExists('#link1s-snp > button:nth-child(1)', 3)
    clickIfElementExists('button.btn-main.get-link', 3)
    clickIfElementExists('.next-button.btn-lg.text-white.btn-info.btn', 3)
    clickIfElementExists('.next-button.text-white.btn-info.btn', 3)
    clickIfElementExists('.btn-outline-white.btn', 3)
    clickIfElementExists('button#bt.btn.btn-info.btn-lg', 3)
    clickIfElementExists('button#btn-main.btn.btn-main', 3)
    clickIfElementExists('button#btn-get-link', 3)
    clickIfElementExists('.col-md-8 > form:nth-child(17) > button:nth-child(3)', 3)
    clickIfElementExists('#cl1 > center:nth-child(1) > a:nth-child(1)', 3)
    clickIfElementExists('div#wpsafe-generate a img', 3)
    clickIfElementExists('a.submitBtn.btn.btn-primary', 3)
    clickIfElementExists('button#submitbtn.g-recaptcha.btn.btn-primary', 3)
    clickIfElementExists('p.getlink', 3)
    clickIfElementExists('button#getlink.getlink.disabled', 3)
    clickIfElementExists('#link1s-snp > button:nth-child(1)', 3)
    clickIfElementExists('#cl1 > a:nth-child(2) > font:nth-child(1)', 3)
    clickIfElementExists('button#mdt.custom-btn.btn-7', 3)
    clickIfElementExists('input#btn-main.btn.btn-primary', 3)
    clickIfElementExists('#cl1 > a:nth-child(1) > font:nth-child(1) > b:nth-child(1)', 3)
    clickIfElementExists('input.btn.btn-primary', 5)
    clickIfElementExists('div.complete a.btn', 5)
    clickIfElementExists('#molien > a:nth-child(1)', 5)
    clickIfElementExists('div#wpsafe-link a img', 5)
    clickIfElementExists('#wpsafe-snp > a:nth-child(1)', 5)
    clickIfElementExists('#wpsafe-snp > center:nth-child(1) > a:nth-child(1)', 5)
    clickIfElementExists('a#surl1.btn-main.get-link', 5)
    clickIfElementExists('button#invisibleCaptchaShortlink.btn-main.get-link', 5)
    clickIfElementExists('.btn-captcha.btn-sm.btn-primary.btn', 5)
    clickIfElementExists('button#invisibleCaptchaShortlink.btn.ybtn.ybtn-accent-color.btn-captcha', 5)
    clickIfElementExists('button#invisibleCaptchaShortlink.btn.btn-outline-primary.btn-lg.btn-block.btn-captcha', 5)
    clickIfElementExists('button#invisibleCaptchaShortlink.btn.btn-primary.btn-goo.btn-captcha', 7)
    clickIfElementExists('button.btn.btn-success', 7)
    clickIfElementExists('div.lds-ellipsis', 9)
    // ============================================
    // setInterval Mode
    // ============================================
    clickIfElementExists('#wg-form > .btnstep1.btn', 3, 'setInterval')
    clickIfElementExists('a#finalx22.btn.btnstep1', 3, 'setInterval')
    clickIfElementExists('#makingdifferenttimer', 3, 'setInterval')
    clickIfElementExists('#myButtonn > span:nth-child(1)', 3, 'setInterval')
    clickIfElementExists('#mdt.btn.btn-primary.text-white.next-button', 3, 'setInterval')
    clickIfElementExists('a.get-link.bg-red-600.px-8.py-2.rounded-md.inline-block', 3, 'setInterval')
    clickIfElementExists('button#main-button.claim-button.btn.btn-lg.btn-accent', 3, 'setInterval')
    clickIfElementExists('.next-button.btn-lg.btn-info.btn', 3, 'setInterval')
    clickIfElementExists('input.g-recaptcha.btn.btn-primary', 3, 'setInterval')
    clickIfElementExists('.get-link.ybtn-accent-color.ybtn.btn', 3, 'setInterval')
    clickIfElementExists('#go_d', 5, 'setInterval')
    clickIfElementExists('#nextButton', 7, 'setInterval')
    clickIfElementExists('.btn-sm.btn-default.btn', 5, 'setInterval')
    clickIfElementExists('#makingdifferenttimer9 > .btn-success.btn', 5, 'setInterval')
    clickIfElementExists('#yuidea-btmbtn', 5, 'setInterval')
    clickIfElementExists('#link1s.btn-primary.btn', 5, 'setInterval')
    clickIfElementExists('a.btn-main.get-link', 5, 'setInterval')
    clickIfElementExists('a.btn.m-2.btn-success', 5, 'setInterval')
    clickIfElementExists('.btn-danger.btn-raised', 5, 'setInterval')
    clickIfElementExists('.close-me > a:nth-child(1)', 5, 'setInterval')
    clickIfElementExists('button.btn-block.btn-success', 5, 'setInterval')
    clickIfElementExists('a.btn.btn-primary.get-link.text-white', 5, 'setInterval')
    clickIfElementExists('div.column:nth-child(2) > font:nth-child(2) > a:nth-child(8)', 3)
    clickIfElementExists('#btn6.btn-captcha.btn-primary.btn', 5, 'setInterval')
    clickIfElementExists('button#link.btn.btn-primary', 5, 'setInterval')
    clickIfElementExists('button#get_link.btn.btn-primary.btn-sm', 7, 'setInterval')
    if (elementExists('#before-captcha')) { setTimeout(function() { document.querySelector('#before-captcha').submit();}, 3000);}
    if (elementExists('#url_qu')) { setTimeout(function() { document.querySelector('.ad-banner.btn-captcha.btn-primary.btn').click();}, 3000);}
    if (elementExists('a#firststep-btn.btn.btnstep1')) { setTimeout(function() { document.querySelector('button#getlink.btn.m-2.btn-success.disabled').click();}, 3000);}
    if (elementExists('div.col-md-4:nth-child(2)')) { setInterval(function() { bp('div.col-md-4:nth-child(2) > span:nth-child(1) > img:nth-child(1)').click();}, 5000);}
    if (elementExists('.tdc_zone')) { setInterval(function() { bp('a.btn-success').click();}, 5000);}
    if (elementExists('#ytimer')) { setInterval(function() { bp('#ytimer > .s-btn-f').click();}, 5000);}
    if (elementExists('#mainlink')) { setInterval(function() { bp('#mainlink > .s-btn-f').click();}, 5000);}
    if (elementExists('#surl')) { setInterval(function() { bp('#surl.btn-success.m-2.btn').click();}, 5000);}
    if (elementExists('#makingdifferenttimer')) { setInterval(function() { bp('#url_qu > a:nth-child(1)').click();}, 3000);}
    if (location.host === 'coin.mg') {} else {if (elementExists('#links')) { setInterval(function() { bp('#links > form:nth-child(2)').submit();}, 3000);}}
    if (location.host === 'aii.sh') {} else { const blockonclick = new Function('console.log("Blocked")')
    if (location.host === 'shortzon.com'){bp('.btn-primary.btn').onclick = blockonclick}}
    if (location.host === 'doctor-groups.com'){setInterval(function() { bp('.skip-ad > a:nth-child(1)').click(); }, 3000);}
    if (location.host === 'www.lootlinks.xyz') { clickIfElementExists('#get-link', 5, 'setInterval')}
    if (location.host === 'profitlink.info') { clickIfElementExists('.btn-captcha.btn-primary.btn', 3, 'setInterval')}
    if (location.host === 'profitlink.info'){setInterval(function() { bp('.calc-earn.get-link.btn-lg.btn-success.btn').click(); }, 5000);}
    if (location.host === 'freebcc.org'){setInterval(function() { bp('.get-link.btn-sm.btn-primary.btn').click(); }, 5000);}
    if(['ctbl.me', 'zshort.cc'].indexOf(location.host) > -1 && location.search === '') {location = 'https://antonimos.de/?url8j=' + location.href}
    if(['linksly.co','shrinke.me','health-and.me','stfly.me','cutdl.xyz','zagl.info','za.gl','shortzon.com','cryptorotator.website'].indexOf(location.host) > -1) {clickIfElementExists('.get-link.btn-lg.btn-success.btn', 5, 'setInterval')}
    if (typeof hcaptcha=="object" && typeof apiCounter=="object") { window.app_country_visitor=""
        window.hcaptcha.getResponse=()=>{}
        window.apiCounter.generateURL()
        window.apiCounter.redirectTo(bp("button.button-element-verification"))}
    if(typeof tokenURL=="string") { redirect(atob(window.tokenURL))}
    waitForElm('div#wpsafe-link > a', function(element) {const regex = /redirect=(.*)',/;
        const m = regex.exec(element.onclick.toString())[1]
        location.href = JSON.parse(atob(m)).safelink})
    let $ = window.jQuery;
    if(['short.goldenfaucet.io','short.croclix.me','www.adz7short.space','shortique.com'].indexOf(location.host) > -1) {function fireMouseEvents(query) { const element = document.querySelector(query);
    if (!element) return; ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(eventName => {if (element.fireEvent) { element.fireEvent('on' + eventName);} else { const eventObject = document.createEvent('MouseEvents');
     eventObject.initEvent(eventName, true, false); element.dispatchEvent(eventObject);}})}
     setInterval(function() { if ($("#link").length > 0) { fireMouseEvents("#link")}}, 500);
     setInterval(function() { if ($("input#continue").length > 0) {fireMouseEvents("input#continue");}
    if ($("a#continue.button").length > 0) {fireMouseEvents("a#continue.button")}}, 9000);
     setTimeout(function() {if ($("#btn-main").length < 0) return; fireMouseEvents("#btn-main")}, 5000);}
    if (location.host === 'upfiles.io') {clickIfElementExists('.get-link.btn-download.btn-primary.btn', 13)} else if (location.host === 'rodjulian.com') {clickIfElementExists('a.btn.btn-primary.btn-lg.get-link', 5, 'setInterval')} else if (elementExists('#go-link')) {$("#go-link").unbind().submit(function(e) {e.preventDefault(); var form = $(this); var url = form.attr('action'); const pesan = form.find('button'); const notforsale = $(".navbar-collapse.collapse");
    const blogger = $(".main-header"); const pemula = $(".col-sm-6.hidden-xs");
    $.ajax({type: "POST",
    url: url,
    data: form.serialize(),
    beforeSend: function(xhr) { pesan.attr("disabled", "disabled");
    $('a.get-link').text('Bypassed by Bloggerpemula');
    notforsale.replaceWith('<button class="btn btn-default , col-md-12 text-center" onclick="javascript: return false;"><b>Thanks for using Bypass All Shortlinks Scripts and for Donations , Regards : Bloggerpemula</b></button>');
    blogger.replaceWith('<button class="btn btn-default , col-md-12 text-center" onclick="javascript: return false;"><b>Thanks for using Bypass All Shortlinks Scripts and for Donations , Regards : Bloggerpemula</b></button>');
    pemula.replaceWith('<button class="btn btn-default , col-md-12 text-center" onclick="javascript: return false;"><b>Thanks for using Bypass All Shortlinks Scripts and for Donations , Regards : Bloggerpemula</b></button>');},
    success: function(result, xhr) {redirect(result.url)}});});}
    const l = (h => {const b = h.pathname === '/verify/' && /^\?([^&]+)/.test(h.search); const p = h.pathname === '/' && h.searchParams.has('link');
    switch (h.host) {
    case 'okrzone.com': if (b) { meta('https://gtlink.co/' + RegExp.$1);} break;
    case 'nawahi1.com': if (b) { meta('https://sh2rt.com/' + RegExp.$1)} break;
    case 'fx4vip.com': bp('div.col-md-12:nth-child(2) > a:nth-child(10)').click(); break;
    case 'medipost.org': if (b) { meta('https://link.medipost.org/' + RegExp.$1)} break;
    case 'ledifha.com': if (b) { meta('https://process.ledifha.com/' + RegExp.$1)} break;
    case 'urlily.com': if (b) { meta('https://shorturl.sh2rt.com/' + RegExp.$1);} break;
    case 'adinsurance.xyz': if (b) { meta('https://blog.adinsurance.xyz/' + RegExp.$1)}break;
    case 'url.magmint.com': if (b) { meta('https://bell.healthyguy.online/' + RegExp.$1)} break;
    case 'speedynews.xyz': if (b) { meta('https://additionalgamer.com/blog/' + RegExp.$1)} break;
    case 'techrayzer.com': if (b) { meta('https://techrayzer.com/insurance/' + RegExp.$1)} break;
    case 'cekip.site': case 'www.cekip.site': if (/^\/go\/([^\/]+)/.test(h.pathname)) { meta(atob(RegExp.$1))} break;
    case 'www.hostingviral.live': case 'www.apk4do.com': if (b) { meta('https://www.dineroshare.com/' + RegExp.$1)} break;
    case 'linkstom.ml': if (p) { meta('https://links.earnfort.in/' + decodeURIComponent(h.searchParams.get('link')))} break;
    case 'madar-24.com': if (p) {meta('https://coupon-fresh.com/' + decodeURIComponent(h.searchParams.get('link')))} break;
    case 'studyuo.com': if (h.pathname === '/pro2/verify/' && /^\?([^&]+)/.test(h.search)) { meta('https://csd.xmod.in/' + RegExp.$1);} break;
    case 'hosting4lifetime.com': if (h.pathname === '/blog/verify/' && /^\?([^&]+)/.test(h.search)) { meta('https://abcshort.com/' + RegExp.$1);} break;
    case 'techmody.io': if (h.pathname === '/' && h.searchParams.has('check')) { meta(decodeURIComponent(h.searchParams.get('check')));} break;
    case 'www.gkqnaexam.com': if (/^\/yuidea\/$/.test(h.pathname) && /^\?([^&]+)/.test(h.search)) { meta('https://web.url2link.com/' + RegExp.$1);} break;
    case 'blog.crazyblog.in': if (/^\/step\d+?\/([^/]+)$/.test(h.pathname)) {return 'https://wplink.online/' + RegExp.$1;} else if (/^\/visit\d+?\/step\d+?\/([^/]+)$/.test(h.pathname)) {
    return 'https://cblink.crazyblog.in/' + RegExp.$1;}break;
    case 'insuranceblog.xyz': if (h.pathname === '/blog/' && h.searchParams.has('link')) {return 'https://gos.insuranceblog.xyz/' + h.searchParams.get('link');}break;
    case 'netfile.cc': if (p) {return 'https://next.netfile.cc/' + h.searchParams.get('link');} break;
    case 'www.gifans.com': case 'gifans.com': if (/^\/link\/([^\/]+)/.test(h.pathname)) {return 'https://shortlink.prz.pw/' + RegExp.$1;}break;
    case 'amazingdarpon.com': if (p) {return 'https://go.zolomix.in/' + h.searchParams.get('link');}break;
    case 'coinbaze.in': case 'techmart4u.in': if (/^\/coinbazeads\/([^\/]+)/.test(h.pathname)) {return 'https://urlfiles.com/' + RegExp.$1;}break;
    case 'mercedesellington.com': case 'model-tas-terbaru.com': if (p) {return 'http://yousm.link/' + h.searchParams.get('link');}break;
    case 'wpking.in': if (p) {return 'https://o.ovlinks.com/' + h.searchParams.get('link');}break;
    case 'anime.dutchycorp.space': case 'movies.dutchycorp.space': case 'tech.dutchycorp.space': case 'cool-time.dutchycorp.space':
        if (/^\/redir[^.]+?\.php$/.test(h.pathname) && h.searchParams.has('code')) {return h.searchParams.get('code') + '?verif=0';}break;
    case 'blogginglass.com': if (h.pathname === '/' && h.searchParams.has('getlink')) {return 'http://go.mozlink.net/' + h.searchParams.get('getlink');
         } else if (h.pathname === '/blog/' && h.searchParams.has('getlink')) {return 'http://go.fire-link.net/' + h.searchParams.get('getlink');}break;
    case 'clickscoin.com': if (/^\/short\/([^/]+)/.test(h.pathname)) { return 'https://short.clickscoin.com/' + RegExp.$1;
         } else if (/^\/shortccsl\/([^/]+)/.test(h.pathname)) { return 'https://ccsl.xyz/' + RegExp.$1;} break;
    case 'dogeclick.net': if (/^\/short\/([^/]+)/.test(h.pathname)) {return 'https://short.clickscoin.com/' + RegExp.$1;
        } else if (/^\/ccsl\/([^/]+)/.test(h.pathname)) {return 'https://ccsl.xyz/' + RegExp.$1;}break;
    case 'short.clickscoin.com': case 'watchdoge.xyz': case 'dogeclick.net': if (/^\/ccsl\/([^/]+)/.test(h.pathname)) {return 'https://ccsl.xyz/' + RegExp.$1;}break;
    case 'exe.io': case 'birdurls.com': case 'dash-free.com': case 'owllink.net': if (h.searchParams.has('api') && h.searchParams.has('url')) {return 'https://' + h.searchParams.get('url');}break;
    case 'crypto-faucet.xyz': if (/^\/claim\/link\/([^\/]+)/.test(h.pathname)) {return 'https://doctor-groups.com/link/' + RegExp.$1;}break;
    case 'faucet.100count.net': if (/^\/fo\/linko\/([^\/]+)/.test(h.pathname)) {return 'https://100count.net/fo/linko/' + RegExp.$1;
        } else if (/^\/clickit\/sh\/([^/]+)/.test(h.pathname)) {return 'https://100count.net/fileo/clicksfile/stats/' + RegExp.$1;}break;
    case 'lux.adinsurance.xyz': if (p) {return 'https://go.adinsurance.xyz/' + h.searchParams.get('link');}break;
    case 'adoco.in': if (/girl([mpwz])oro\/([^\/]+)/.test(h.pathname)) { return 'https://girl' + RegExp.$1 + 'oro.xyz/' + RegExp.$2;}break;
    case 'foodyrecipe.xyz': if (p) { return 'https://paid4.link/' + h.searchParams.get('link');} break;
    case 'digitalnaz.net': if (h.pathname === '/' && h.searchParams.has('getlink')) {return 'https://go.linkfly.io//' + h.searchParams.get('getlink'); } break;
    case 'wiki-topia.com': if (p) { return 'https://cryptowidgets.net/sl/' + h.searchParams.get('link');} break;
    case 'infinityfreescripts.xyz': if (p) { return 'https://technologylover.in/' + h.searchParams.get('link'); } break;
    case 'technicalramno1.link': if (p) { return 'https://go.urlmoney.xyz/' + h.searchParams.get('link'); } break;
    case 'informaxonline.com': case 'gaminplay.com': if (p) { return 'https://go.adslinkfly.online/' + h.searchParams.get('link');} break;
    case 'network-earn.online': if ( h.searchParams.has('tok') && h.href.includes('index.php') ) { return 'https://luckybits.online/check.php?tok=' + h.searchParams.get('tok'); } break;
    case 'btc.freebcc.org': case 'eth.freebcc.org': if (h.pathname === '/' && h.searchParams.has('claim')) { return 'https://freebcc.org/' + h.searchParams.get('claim');} break;
    case 'adcortoltda.agency': if (p) { return 'https://link.adcortoltda.agency/' + h.searchParams.get('link');} break;
    case 'takez.co': case 'www.takez.co': if (h.pathname === '/' && h.searchParams.has('token')) { return 'https://links.spidermods.in/' + h.searchParams.get('token'); } break;
    case 'www.digiromotion.com': case 'www.visflakes.com': if (h.pathname === '/' && h.searchParams.has('re')) { return 'https://zipfy.link/' + h.searchParams.get('re'); } break;
    case 'shrinkearn.com': case 'clk.sh': var l = new URL(window.location.href); if (l.href.includes('bloogerspoot.') && l.searchParams.has('url')) {let i = new URL(l.searchParams.get('url'));
         window.location.assign('https://softindex.website'+i.pathname);} break;
    case 'acortame.xyz': if (window.location.hash) {location.href ="https://faucetpay.nurul-huda.or.id/?url="+(atob(window.location.hash.substr(1)))} break;
    case 'claimclicks.com': if (h.pathname === '/blog/' && h.searchParams.has('link')) { return 'https://claimclicks.com/short/' + h.searchParams.get('link');} break;
    case 'newsharsh.com': if (h.pathname === '/english/verify/' && /^\?([^&]+)/.test(h.search)) { meta('https://redd.crazyblog.in/' + RegExp.$1);} break;
    case 'crazyblog.in': case 'www.crazyblog.in': if (h.pathname === '/xhod/verify/' && /^\?([^&]+)/.test(h.search)) { meta('https://redd.crazyblog.in/' + RegExp.$1);} else if (h.pathname === '/' && h.searchParams.has('postid')) {return h.searchParams.get('postid');}break;
    case 'insurance-space.xyz': if (p) { return 'https://link.insurance-space.xyz/' + h.searchParams.get('link');} break;
    case 'theconomy.me': if (p) { return 'https://link.theconomy.me/' + h.searchParams.get('link');} break;
    case 'go.insurglobal.xyz': if (p) { return 'https://link.insurglobal.xyz/' + h.searchParams.get('link');} break;
    case 'techydino.net': if (h.pathname === '/golink.php' && h.searchParams.has('li')) {return 'https://mdn.world/golink.php?li=' + h.searchParams.get('li');}break;
    case 'coin-free.com': case 'kienthucrangmieng.com': case 'coindoog.com': if (h.pathname === '/' && h.searchParams.has('wpsafelink')) { return h.searchParams.get('wpsafelink'); }break;
    case 'esenr.com': if (p) { return 'https://go.bcdshort.xyz/' + h.searchParams.get('link');} break;
    case 'sl.easysl.click': if (/^\/step1\/([^\/]+)/.test(h.pathname)) {return 'https://easysl.click/' + RegExp.$1;}break;
    case 'konstantinova.net': if (/^\/verify\/([^\/]+)/.test(h.pathname)) {return 'https://coin.mg/' + RegExp.$1;}break;
    case 'step0.shortlinks.click': if (/^\/([^\/]+)/.test(h.pathname)) { return 'https://shortlinks.click/' + RegExp.$1; } break;
    case 'earnfree.cc': if (/^\/slc\/step1\/([^/]+)/.test(h.pathname)) { return 'http://shortlinks.click/' + RegExp.$1; } break;
    case 'go.birdurls.com': case 'go.owllink.net': if (/^\/(.+)/.test(h.pathname)) { location = location.href.replace('go.', '');} break;
    case 'link.linksfire.co': if (/^\/(.+)/.test(h.pathname)) { location = location.href.replace('link', 'blog');} break;
    case 'zonearn.biz': if (/^\/(.+)/.test(h.pathname) && h.searchParams.has('tok')) {return h.searchParams.get('tok');}break;
    case 'www.oyunzak.com': case 'www.gazianteppetektemizleme.net': if (h.searchParams.has('link')) {return h.searchParams.get('link');}break;
    case 'tr.link': if (h.searchParams.has('api') && h.searchParams.has('url')) {return h.searchParams.get('url');}break;
    case 'nulledsafe.com': if (/^\/link\/([^\/]+)/.test(h.pathname)) {return 'https://golink.nulledsafe.com/' + RegExp.$1;}break;
    case 'coinsearns.com': if (/^\/cryptoads\/([^/]+)/.test(h.pathname)) {return 'https://cryptoads.space/' + RegExp.$1;}break;
    case 'supersites.xyz': if (h.pathname === '/verifysl.php' && h.searchParams.has('url')) {return h.searchParams.get('url');}break;
    default: break;} })(new URL(location.href)); if (l) {location.href = l; }
    BypassedByBloggerPemula(/tei.ai/, function() {window.addEventListener('DOMContentLoaded', (event) => {var linkbypass = atob(`aH${bp("#link-view [name='token']").value.split("aH").slice(1).join("aH")}`);
    redirect(linkbypass);});})
    BypassedByBloggerPemula(/anonym.ninja/, function() {var fd = window.location.href.split('/').slice(-1)[0]
    redirect(`https://anonym.ninja/download/file/request/${fd}`)})
    BypassedByBloggerPemula(/btcpany.com|crewbase.net|crewus.net|thumb8.net|thumb9.net|allcryptoz.net|topcryptoz.net|ultraten.net|uniqueten.net|jiotech.net|technoflip.in|studyranks.in|brixarena.tech|crypto4tun.com|askpaccosi.com|mcrypto.club|faucet.work|wildblog.me|bebodybuilder.com|mrsaifi.xyz|techlearningtube.in|manthans.in|dogeearn.com|crypto-blog.xyz|claimfey.com/, function() {const el = document.querySelector("input[name=newwpsafelink]")
    redirect(JSON.parse(atob(el.value)).linkr)})
    BypassedByBloggerPemula(/cryptomonitor.in|crickblaze.com|shinchu.net|shinbhu.net|riadblog.com|riadcrypto.com|donia2tech.com|www.cgyojna.com|saqercoin.xyz|2the.space/, function() {const form = document.getElementById('wpsafelink-landing')
    redirect(JSON.parse(atob(form.newwpsafelink.value)).linkr)})
    BypassedByBloggerPemula(/vsbl.ga|stex.link|iir.ai|shortzon.com|celinks.net|cryptowidgets.net|urlchanger.ml|nabits.xyz|d.bawabatak.com|www.adshort-url.com|nukl.ink|tronex.biz|playgotoken.com|sl.claimfreebits.com|yocto.link|linksfy.co|mitly.us|skincarie.com|linksos.live|cryptorotator.website/, function() {
    bp('button.btn:nth-child(4)').click();})
    BypassedByBloggerPemula(/getitall.top|pentafaucet.com/, function() {const short_id = location.pathname.split('/')[2];
    next(short_id)
    setTimeout(function() {complete(short_id)}, 4000)})
    BypassedByBloggerPemula(/hitbits.io/, function() {const short_id = location.pathname.split('/')[3];
    next(short_id)
    setTimeout(function() {complete(short_id)}, 4000)})
    BypassedByBloggerPemula(/7apple.net/, ['go', 'https://illink.net/'], false)
    const re = new RegExp(/^\?([^&]+)/);
    BypassedByBloggerPemula(/crazyblog.in/, { '/finance/': ['link', 'https://shrinkpay.crazyblog.in'],
    '/hars/verify/': [re, 'https://redd.crazyblog.in'],
    '/harsh/verify/': [re, 'https://studyuo.com/pro2/verify/?'],}, false)
    BypassedByBloggerPemula(/studyuo.com/, {'/pro/': ['link', 'https://shrinkpay.crazyblog.in'],
    '/short/verify/': [re, 'https://redd.crazyblog.in'],
    '/blog/verify/': [re, 'https://speedynews.xyz/verify/?'],}, false)
    BypassedByBloggerPemula(/insuranceblog.xyz/, { '/blog/': ['link', 'https://gos.insuranceblog.xyz/']}, false)
    BypassedByBloggerPemula(/netfile.cc/, ['link', 'https://next.netfile.cc/'], false)
    BypassedByBloggerPemula(/amazingdarpon.com/, ['link', 'https://go.zolomix.in/'], false)
    BypassedByBloggerPemula(/prx.ee/, function() { bp('#final_link').click();})
    BypassedByBloggerPemula(/1ink.cc/, function() { bp('#countingbtn').click();})
    BypassedByBloggerPemula(/1link.club/, function() { bp('#download').click();})
    BypassedByBloggerPemula(/up-load.one/, function() { bp('#submitbtn').click();})
    BypassedByBloggerPemula(/jameeltips.us/, function() { bp('#continue_button_1').click();})
    BypassedByBloggerPemula(/shortit.pw/, function() { bp('.pulse.btn-primary.btn').click();})
    BypassedByBloggerPemula(/ashort1a.xyz|ashort2a-bro.tk/, function() { bp('#proceed').click();})
    BypassedByBloggerPemula(/link.wrbloggers.com/, function() { bp('.btn-danger.btn-block.btn').click();})
    BypassedByBloggerPemula(/techload.co|largestpanel.in|earn.largestpanel.in/, function() { bp('#tp-snp2').click();})
    BypassedByBloggerPemula(/forex-articles.com|forexlap.com|forexmab.com/, function() { bp('.oto > a:nth-child(1)').click();})
    BypassedByBloggerPemula(/marocclickers.xyz/, function() { bp('#link-view > div:nth-child(5) > center:nth-child(5) > div:nth-child(1)').click();})
    BypassedByBloggerPemula(/stfly.me/, function() { bp('#submit_data').submit();})
    BypassedByBloggerPemula(/forex-trnd.com/, function() { bp('#exfoary-form').submit();})
    BypassedByBloggerPemula(/adsy.pw|linkpay.cc/, function() { bp('#link-view').submit();})
    BypassedByBloggerPemula(/makemoneywithurl.com/, function() { bp('#hidden form').submit();})
    BypassedByBloggerPemula(/automotur.club|sanoybonito.club/, function() { bp('#page2').submit();})
    BypassedByBloggerPemula(/go.techgeek.digital/, function() { bp('.text-center > form:nth-child(4)').submit();})
    BypassedByBloggerPemula(/intercelestial.com|tribuntekno.com|101desire.com/, function() { bp('#landing').submit();})
    const bas = (h => { const result = { isNotifyNeeded: false, redirectDelay: 0, link: undefined };
    switch (h.host) {case 'faucetpay.nurul-huda.or.id': if (h.pathname === '/' && h.searchParams.has('url') && h.searchParams.has('sn')) {
          result.link = h.searchParams.get('url') + '&sn=' + h.searchParams.get('sn').replace('&m=1', ''); result.redirectDelay = 5; result.isNotifyNeeded = true; return result;
        } else if (h.pathname === '/' && h.searchParams.has('url') && h.searchParams.has('ssa') && h.searchParams.has('id')) {
          result.link = h.searchParams.get('url') + '&ssa=' + h.searchParams.get('ssa') + '&id=' + h.searchParams.get('id').replace('&m=1', ''); result.redirectDelay = 5; result.isNotifyNeeded = true; return result;
        } else if (h.pathname === '/' && h.searchParams.has('url') && h.searchParams.has('id')) {
          result.link = h.searchParams.get('url') + '&id=' + h.searchParams.get('id').replace('&m=1', ''); result.redirectDelay = 5; result.isNotifyNeeded = true; return result;
        } else if (h.pathname === '/' && h.searchParams.has('url') && h.searchParams.has('article')) {
          result.link = h.searchParams.get('url') + '&article=' + h.searchParams.get('article').replace('&m=1', ''); result.redirectDelay = 5; result.isNotifyNeeded = true; return result;
        } else if (h.pathname === '/' && h.searchParams.has('url')) {
          result.link = h.searchParams.get('url').replace('&m=1', ''); result.redirectDelay = 30; result.isNotifyNeeded = true; return result; } break;
        default: break;}})(new URL(location.href));
    if (bas) { const { isNotifyNeeded, redirectDelay, link } = bas;
    if (isNotifyNeeded) { notify(`Please Wait a moment .....You will be Redirected to Your Destination in ${redirectDelay} seconds`);}
        setTimeout(() => {location.href = link}, redirectDelay * 1000);}
})();