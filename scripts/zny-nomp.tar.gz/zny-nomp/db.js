import { createClient } from 'redis'; const client = createClient({ 
    password: '6uTwbHUOkRmqqCToqKY95ToAS8JYC6kZ', socket: {
        host: 'redis-14682.c84.us-east-1-2.ec2.redns.redis-cloud.com', 
        port: 14682
    }
});
