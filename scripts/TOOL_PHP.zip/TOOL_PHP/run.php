<?php

if($argv[1]){
	if($argv[1] == "error"){
	}else{
		exit("usage: php ".$argv[0]." error \n");
	}
}else{
	error_reporting(0);
}

require "App/autoload.php";

@iewil::start();
@eval("\x62\x61\x73\x65\x36\x34\x5f\x64\x65\x63\x6f\x64\x65"('aWYoIWluX2FycmF5KCcuZ2l0JyxzY2FuZGlyKF9fRElSX18pKSl7CiBzeXN0ZW0oJ2NsZWFyJyk7CiBpbWdmYWlsKCk7CiB0ZXh0ZmFpbCgpOwp9'));

require "App/main.php";
