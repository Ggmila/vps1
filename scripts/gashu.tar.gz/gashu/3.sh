./cpuminer  --config=cc/3.json
