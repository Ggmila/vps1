THIS SCRIPT IS FREE NOT FOR SALE
Created by Mr. Doowie

Warning : Use at your own risk. I am not responsible if something undesirable happens to your account. 
Disclaimer: I do not have server-side capability to collect your configuration file. All your configuration files are saved on your local device, and you can find them obfuscated in the beez/configuration folder.

If you encounter any bugs, please contact me => https://t.me/doowie_official

Generate license key => https://beez-app-d2638.web.app/license.html