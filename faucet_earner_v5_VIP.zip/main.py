import re
import os
import sys
import json
import html
import base64
import requests
from time import sleep
from bs4 import BeautifulSoup
from datetime import datetime, timedelta, timezone
from json.decoder import JSONDecodeError
from random import randint, choice, uniform
from colorama import Fore, Back, Style, init
from requests.exceptions import RequestException, ConnectionError, Timeout
from http.cookies import SimpleCookie

s = requests.Session()

init(autoreset=True)

sc_ver = "FAUCET EARNER v5"
host = 'faucetearner.org'

minutes = 1

end = "\033[K"
res = Style.RESET_ALL
red = Style.BRIGHT+Fore.RED
bg_red = Back.RED
white = Style.BRIGHT+Fore.WHITE
green = Style.BRIGHT+Fore.GREEN
yellow = Style.BRIGHT+Fore.YELLOW
colors = [Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN]

def clean_screen():
    os.system("clear" if os.name == "posix" else "cls")

class Bot:
    
    def __init__(self):
        self.best_claim = 0
        self.streak = 0

    def curl(self, method, url, data=None):
        headers = {'user-agent': self.user_agent}
        while True:
            try:
                r = s.request(method, url, headers=headers, data=data, timeout=10)
                if r.status_code == 200:
                    return r
                elif r.status_code == 403:
                    self.carousel_msg("Access denied")
                    return None
                elif 500 <= r.status_code < 600:
                    self.carousel_msg(f"Server {host} down.")
                else:
                    self.carousel_msg(f"Unexpected response code: {r.status_code}")
                    return None
            except ConnectionError:
                self.carousel_msg(f"Reconnecting to {host}")
            except Timeout:
                self.carousel_msg("Too many requests")
            self.wait(10)

    def wait(self, x):
        for i in range(x, -1, -1):
            col = yellow if i%2 == 0 else white
            animation = "⫸" if i%2 == 0 else "⫸⫸"
            m, s = divmod(i, 60)
            t = f"[00:{m:02}:{s:02}]"
            sys.stdout.write(f"\r  {white}Please wait {col}{t} {animation}{res}{end}\r")
            sys.stdout.flush()
            sleep(1)

    def carousel_msg(self, message):
        def first_part(message, wait):
            animated_message = message.center(48)
            msg_effect = ""
            for i in range(len(animated_message) - 1):
                msg_effect += animated_message[i]
                sys.stdout.write(f"\r {msg_effect}{res} {end}")
                sys.stdout.flush()
                sleep(0.03)
            if wait:
                sleep(1)

        msg_effect = message[:47]
        wait = True if len(message) <= 47 else False
        first_part(msg_effect, wait)
        if len(message) > 47:
            for i in range(50, len(message)):
                msg_effect = msg_effect[1:] + message[i]
                if i > 1:
                    sys.stdout.write(f"\r {msg_effect} {res}{end}")
                    sys.stdout.flush()
                sleep(0.1)
        sleep(1)
        sys.stdout.write(f"\r{res}{end}\r")
        sys.stdout.flush()

    def msg_line(self):
        print(f"{green}{'━' * 50}")

    def msg_action(self, action):
        now = datetime.now()
        now = now.strftime("%d/%b/%Y %H:%M:%S")
        total_length = len(action) + len(now) + 5
        space_count = 50 - total_length
        msg = f"[{action.upper()}] {now}{' ' * space_count}"
        print(f"{bg_red} {white}{msg}{res}{red}⫸{res}{end}")

    def mainbot(self):
        
        def lottery():
            self.carousel_msg("Go to lottery section")
            while True:
                r = self.curl('GET', f"https://{host}/referrals.php")
                if r:
                    soup = BeautifulSoup(r.text, 'html.parser')
                    tickets = soup.find('b', {'id': 'reward'}).text
                    if tickets is not None and tickets.isdigit() and int(tickets) > 0:
                        r =  self.curl('POST', f"https://{host}/api.php?act=reward")
                        if r:
                            r = json.loads(r.text)
                            if 'message' in r and r['message']:
                                v = self.data_account()
                                match = re.search(r'(\d+\.\d+) XRP', r['message'])
                                if match:
                                    earn = match.group(1)
                                else:
                                    earn = 0
                                earn = "{:.8f}".format(float(earn))
                                self.msg_action("LOTTERY")
                                print(f" {red}# {white}Reward: {green}{earn}{res} XRP{end}")
                                print(f" {red}# {white}Balance: {green}{v['total_bal']}{res} XRP{end}")
                                self.msg_line()
                            else:
                                print(r)
                            return
                    else:
                        self.carousel_msg("Not availables tickets")
                        return
                        
        def faucet():
            self.carousel_msg("Go to faucet section")
            while True:
                r =  self.curl('POST', f"https://{host}/api.php?act=faucet")
                if r:
                    r = json.loads(r.text)
                    if 'message' in r and r['message']:
                        v = self.data_account()
                        match = re.search(r'(\d+\.\d+) XRP', r['message'])
                        if match:
                            earn = match.group(1)
                        else:
                            earn = 0
                        earn = "{:.8f}".format(float(earn))
                        if float(earn) > self.best_claim:
                            self.streak = 1
                            self.best_claim = float(earn)
                        elif float(earn) == self.best_claim:
                            self.streak += 1
                        best_claim = "{:.8f}".format(self.best_claim)
                        self.msg_action("FAUCET")
                        print(f" {red}# {white}Reward: {green}{earn}{res} XRP{end}")
                        print(f" {red}# {white}Balance: {green}{v['total_bal']}{res} XRP{end}")
                        print(f" {red}# {white}Highest Reward: {green}{best_claim}    -    {white}Streak: {yellow}{self.streak}{res}{end}")
                        self.msg_line()
                    else:
                        print(r)
                    return
        
        def history_wd(opt=None):
            self.carousel_msg("Go to history withdraw section")
            while True:
                r = self.curl('GET', f"https://{host}/withdraw.php")
                if r:
                    soup = BeautifulSoup(r.text, 'html.parser')
                    history = soup.select('.welcome-card table.text-center tbody tr')
                    if history:
                        if opt and opt == 'tx':
                            tx_hash = history[0].find('a', class_='text-primary')
                            tx_hash = tx_hash['href'] if tx_hash else None
                            return tx_hash
                        if any(val is None for val in history):
                            continue
                        for i in range(len(history)):
                            tx_hash = history[i].find('a', class_='text-primary')
                            tx_hash = tx_hash['href']
        
                            amount = history[i].find('td', translate='no')
                            amount = amount.get_text(strip=True)
        
                            status = history[i].find('span', style='color: #38cf89')
                            status = status.get_text(strip=True)
        
                            date = history[i].find('div', style='width: 150px;')
                            date = date.get_text(strip=True)
                            if opt and opt == 'last wd' and i == (len(history)-1):
                                try:
                                    return datetime.strptime(date, "%d/%m/%Y %H:%M")
                                except Exception:
                                    return None
                    else:
                        self.carousel_msg("Not withdrawal history found.")
                        return 'first wd'
                else:
                    self.carousel_msg("Error getting withdrawal history.")
                return None

        def withdraw():
            self.carousel_msg("Go to withdraw section")
            while True:
                r = self.curl('GET', f"https://{host}/withdraw.php")
                if r:
                    soup = BeautifulSoup(r.text, 'html.parser')
                    amount = soup.find('input', {'id': 'withdraw_amount'})['value']
                    self.carousel_msg("Checking if amount >= min withdrawl")
                    try:
                        amount_wd = float(amount)
                        if amount_wd < 0.01:
                            self.carousel_msg("Wd amount is very low")
                            break
                    except Exception:
                        self.carousel_msg("Error read amount")
                        break
                    self.carousel_msg("Checking date last withdrawal")
                    last_date_wd = history_wd(opt='last wd')
                    if last_date_wd:
                        if last_date_wd != 'first wd':
                            local_time = datetime.now()
                            local_time_utc = local_time.astimezone(timezone.utc)
                            local_time_utc = local_time_utc.replace(tzinfo=None)
                        if last_date_wd == 'first wd' or isinstance(last_date_wd, datetime) and local_time_utc >= last_date_wd:
                            if amount:
                                payload = {'amount': str(amount), 'wallet': str(self.wallet), 'tag': str(self.tag)}
                                payload = json.dumps(payload)
                                r =  self.curl('POST', f"https://{host}/api.php?act=withdraw", payload)
                                if r:
                                    r = json.loads(r.text)
                                    if 'message' in r:
                                        self.carousel_msg(r['message'])
                                        if 'insufficient balance' in r['message'] or 'withdrawal time is too long' in r['message']:
                                            break
                                        elif 'successfully' in r['message']:
                                            tx_hash = history_wd(opt='tx')
                                            amount = "{:.8f}".format(float(amount))
                                            self.msg_action("WITHDRAW")
                                            wd_status = 'Completed' if tx_hash else 'Pending'
                                            print(f" {red}# {white}Status: {yellow}{wd_status}{end}")
                                            print(f" {red}# {white}Amount: {green}{amount}{res} XRP{end}")
                                            print(f" {red}# {white}Address XRP: {yellow}{self.wallet}{res}{end}")
                                            print(f" {red}# {white}Tag Address XRP: {white}{self.tag}{res}{end}")
                                            self.msg_line()
                                            break
                                        else:
                                            print(r)
                                    else:
                                        print(r)
                                else:
                                    self.carousel_msg("Error making withdraw")
                            else:
                                self.carousel_msg("Error getting max amount withdrawal now, try later moment")
                        else:
                            self.carousel_msg("You still cannot make a new withdrawal ")
                    break
                        
        v = self.data_account()
        print(f"\n{bg_red}{white} ๏ {res} {yellow}〔 USERNAME 〕............: {res}{v['username']}{end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 TOTAL BALANCE 〕.......: {res}{v['total_bal']} XRP{end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 FAUCET EARNINGS 〕.....: {res}{v['faucet_earn']} XRP{end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 PTC EARNINGS 〕........: {res}{v['ptc_earn']} XRP {end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 INVESTMENT EARNINGS 〕.: {res}{v['invest_earn']} XRP {end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 REFFERALS EARNINGS〕...: {res}{v['reff_earn']} XRP{end}")
        print(f"{res}{end}")
        self.msg_line()
        start_check_wd = datetime.now()
        next_check_wd = start_check_wd
        while True:
            sleep(2)
            self.wait(minutes * 60)
            faucet()
            lottery()
            if self.autowd and self.wallet and self.tag:
                current_time = datetime.now()
                if current_time >= next_check_wd:
                    withdraw()
                    start_check_wd = datetime.now()
                    next_check_wd = start_check_wd + timedelta(minutes=60)

    def write_file(self, data):
        with open('config.json', 'w') as f:
            json.dump(data, f, indent=4)

    def data_account(self):
        self.carousel_msg("Getting user info")
        while True:
            url = f"https://{host}/dashboard.php"
            r = self.curl('GET', url)
            v = {}
            soup = BeautifulSoup(r.text, 'html.parser')
            username = soup.find('p', {'style': 'max-width: 130px;overflow: hidden;text-wrap: nowrap;text-overflow: ellipsis;'})
            v['username'] = username.text.strip() if username else None
    
            keywords = {
                'total_bal': 'Total Balance:',
                'faucet_earn': 'Faucet Earnings:',
                'ptc_earn': 'PTC Earnings:',
                'invest_earn': 'Investment Earnings:',
                'reff_earn': 'Referrals Earnings:'
            }
            
            for key, value in keywords.items():
                element = soup.find('div', string=lambda text: text and value in text).find_next('b', {'translate': 'no'})
                v[key] = element.text.split(' ')[0].strip() if element else None
                if v[key] is not None:
                    v[key] = "{:.8f}".format(float(v[key]))
    
            if any(value is None or len(value) < 5 for value in v.values()):
                continue
            else:
                break
        return v
    
    def config(self):
        def get_valid_user_agent():
            user_agent = ''
            while len(user_agent) < 10 or 'Mozilla' not in user_agent:
                user_agent = input(f"{yellow}Enter User-Agent{red}:{res} ")
            return user_agent.strip()
    
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            config = {'User-Agent': get_valid_user_agent(), 'Wallet': '', 'Tag': ''}
    
        self.user_agent = config['User-Agent']
    
        auto_wd_choice = ''
        while auto_wd_choice not in ["y", "n"] or auto_wd_choice.isspace():
            auto_wd_choice = input(f"{yellow}Do you want to activate 'auto withdraw'? (y/n):{res} ").lower()
            if auto_wd_choice not in ["y", "n"] or auto_wd_choice.isspace():
                print("Please enter a valid choice ('y' or 'n').")
    
        self.autowd = True if auto_wd_choice == 'y' else False
    
        if self.autowd:
            keywords = ['Wallet', 'Tag']
            for key in keywords:
                while len(config[key]) < 5:
                    config[key] = input(f"\n{yellow}{key}{red}:{res} ")
            self.wallet = config['Wallet']
            self.tag = config['Tag']
    
        with open('config.json', 'w') as f:
            json.dump(config, f)
    
        cookies = input(f"\n{yellow}Cookies{red}:{res} ")
        cookie_obj = SimpleCookie()
        cookie_obj.load(cookies)
    
        cookie_jar = requests.cookies.RequestsCookieJar()
        for morsel in cookie_obj.values():
            cookie_jar.set(morsel.key, morsel.value)
    
        s.cookies = cookie_jar

bot = Bot()
bot.autowd = False
bot.config()

clean_screen()
bot.msg_line()
print(f"{green}{sc_ver.center(50, ' ')}")
bot.msg_line()

bot.mainbot()
