<?php

# Access Permission 
# server Connect 



#$key = "LSOLVKZO41uTHnbL2b8QX06BmdgGUD01";

$user = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";


$cookie = "_ga=GA1.1.160786584.1702721221; bitmedia_fid=eyJmaWQiOiJjNjUyNGNlMDc5YTE5MWQ5YTQ2NTcwMGQwNTg1Mjk4MSIsImZpZG5vdWEiOiI1ODJlMDliNzJlY2Q1YTAxZGRjY2E1MDIzY2UzZTU5YiJ9; ctuid=9a6e1f85-66b1-4cdc-a065-00be798da524; SesHashKey=9y3l82qwapkorza0; SesToken=ses_id=7114&ses_key=9y3l82qwapkorza0; AccExist=7114; _ga_WEG5YYRSWD=GS1.1.1706190801.39.0.1706190801.0.0.0; PHPSESSID=459f37e46b7edf5a163596dd89d45c0a";