import re
import os
import sys
import json
import time
import requests
from time import sleep
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from json.decoder import JSONDecodeError
from random import randint, choice, uniform
from colorama import Fore, Back, Style, init
from requests.exceptions import RequestException, ConnectionError, Timeout

solver_session = {
    'multibot': requests.Session(),
    'xevil': requests.Session()
}

init(autoreset=True)

sc_ver = 'MULTI TREASURE CHEST'

end = "\033[K"
res = Style.RESET_ALL
red = Style.BRIGHT+Fore.RED
bg_red = Back.RED
white = Style.BRIGHT+Fore.WHITE
lila = Style.BRIGHT+Fore.MAGENTA
celeste = Style.BRIGHT+Fore.CYAN
green = Style.BRIGHT+Fore.GREEN
yellow = Style.BRIGHT+Fore.YELLOW
colors = [Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN]

def clean_screen():
    os.system("clear" if os.name == "posix" else "cls")

def banner():
    clean_screen()
    msg_line()
    print(f"{green}{sc_ver.center(50, ' ')}")
    msg_line()

def save_log(html, namefile):
    soup = BeautifulSoup(html.text, 'html.parser')
    body = soup.prettify()
    with open(f"{namefile}.html", "w", encoding="utf-8") as file:
        file.write(body)

def wait(x):
    for i in range(x, -1, -1):
        col = yellow if i%2 == 0 else white
        animation = "⫸" if i%2 == 0 else "⫸⫸"
        m, s = divmod(i, 60)
        t = f"[00:{m:02}:{s:02}]"
        sys.stdout.write(f"\r  {white}Please wait {col}{t} {animation}{res}{end}\r")
        sys.stdout.flush()
        sleep(1)

def carousel_msg(message):
    def first_part(message, wait):
        animated_message = message.center(48)
        msg_effect = ""
        for i in range(len(animated_message) - 1):
            msg_effect += animated_message[i]
            sys.stdout.write(f"\r {msg_effect}{res} {end}")
            sys.stdout.flush()
            sleep(0.03)
        if wait:
            sleep(1)

    msg_effect = message[:47]
    wait = True if len(message) <= 47 else False
    first_part(msg_effect, wait)
    if len(message) > 47:
        for i in range(50, len(message)):
            msg_effect = msg_effect[1:] + message[i]
            if i > 1:
                sys.stdout.write(f"\r {msg_effect} {res}{end}")
                sys.stdout.flush()
            sleep(0.1)
    sleep(1)
    sys.stdout.write(f"\r{res}{end}\r")
    sys.stdout.flush()

def msg_line():
    print(f"{green}{'━' * 50}")

def msg_action(action):
    now = datetime.now()
    now = now.strftime("%d/%b/%Y %H:%M:%S")
    total_length = len(action) + len(now) + 5
    space_count = 50 - total_length
    msg = f"[{action.upper()}] {now}{' ' * space_count}"
    print(f"{bg_red} {white}{msg}{res}{red}⫸{res}{end}")

def write_file(data):
    with open('config.json', 'w') as f:
        json.dump(data, f, indent=4)

def get_time():
    return datetime.now().strftime("%H:%M:%S %d/%b")

class Bot:
    
    def curl(self, method, url, data=None):
        attemps = 0
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'conttent-type': 'application/x-www-form-urlencoded',
            'user-agent': self.user_agent
        }
        
        while True:
            try:
                r = self.sessions[self.current_host][self.current_email].request(method, url, headers=headers, data=data, timeout=10)
                if 200 <= r.status_code < 400:
                    return r
                elif r.status_code == 403:
                    carousel_msg("Access denied")
                    sleep(10)
                    return None
                elif 500 <= r.status_code < 600:
                    carousel_msg(f"Server {self.current_host} down.")
                    return
                else:
                    carousel_msg(f"Unexpected response code: {r.status_code}")
                    print(r.text)
                    return None
            except ConnectionError:
                carousel_msg(f"Reconnecting to {self.current_host}")
            except Timeout:
                carousel_msg("Timeout reached")
            attemps += 1
            if attemps >= 10:
                for i, host in enumerate(self.list_hosts):
                    if host == self.current_host:
                        if i + 1 < len(self.list_hosts):
                            self.current_host = self.list_hosts[i + 1]
                        else:
                            self.current_host = self.list_hosts[0]
                        break
                carousel_msg("Reseting hosts")
                self.mainbot()
            wait(10)
            
    def solver(self, start_check=False):
        
        def curl(method, url, data=None):
            while True:
                try:
                    r = solver_session[self.service_solver].request(method, url, data=data, timeout=30)
                    if r.status_code == 200:
                        return r.text
                    if r.status_code >= 500:
                        carousel_msg(f"{self.service_solver.capitalize()} is down now")
                except ConnectionError:
                    carousel_msg(f"Reconnecting to {self.service_solver.capitalize()}")
                except Timeout:
                    carousel_msg("Too many requests")
                    carousel_msg("Plase wait a few seconds")
                except RequestException as e:
                    carousel_msg(f"Unexpected requests, Error: {e}")
                carousel_msg("Please wait a few seconds")
                wait(randint(10,30))

        def get_solved():
            
            nonlocal id_task
            
            carousel_msg("Getting result solver")
            def get_url_task():
                expar = 'action=get&' if self.service_solver == 'multibot' else ''
                return f"{url_solver}/res.php?key={api_key}&{expar}id={id_task}"

            url = get_url_task()
            
            while True:
                r = curl('GET', url)
                if 'CAPCHA_NOT_READY' in r:
                    self.captcha['count']['attemps'] += 1
                    self.captcha['count']['t_attemps'] += 1
                    carousel_msg(f"Captcha not ready  ●  Attemps: [ {self.captcha['count']['attemps']}/{self.captcha['count']['t_attemps']} ]")
                    if self.captcha['count']['attemps'] >= 25:
                        carousel_msg("Requesting new task")
                        self.captcha['count']['attemps'] = 0
                        id_task = get_id_task()
                        url = get_url_task()
                elif '|' in r:
                    carousel_msg("Success get result")
                    self.captcha['count']['attemps'] = 0
                    self.captcha['count']['t_attemps'] = 0
                    return r.split("|")[1]
                else:
                    self.captcha['count']['attemps'] = 0
                    carousel_msg("Error requesting result")
                    sleep(1)
                    id_task = get_id_task()
                    url = get_url_task()
                    
        def get_id_task():
            carousel_msg("Getting id task")
            payload = {'key': api_key, 'method': type_captcha, 'pageurl': pageurl, 'sitekey': sitekey}
            
            while True:
                r = curl('POST', f"{url_solver}/in.php", payload)
                if '|' in r:
                    carousel_msg("Success created id task")
                    return r.split("|")[1]
                else:
                    print(r)
                    carousel_msg(f"Error creating {type_captcha} id task")
                sleep(1)
        
        def get_balance():
            carousel_msg(f"Getting balance {self.service_solver.lower()}")
            action = 'userinfo' if self.service_solver.lower() == 'multibot' else 'getbalance'
            
            while True:
                userinfo = curl('GET', f"{url_solver}/res.php?action={action}&key={api_key}")
                if self.service_solver.lower() == "multibot":
                    if userinfo == '[]':
                        print(f"{red}Bad {self.service_solver.lower()} api key{res}{end}")
                        exit()
                    userinfo = json.loads(userinfo)
                    if userinfo['balance'] and userinfo['balance'].isdigit():
                        balance = int(userinfo['balance'])
                        if int(balance) <= 0:
                            if start_check:
                                return 0
                            print(f"{red}Dont have balance in {self.service_solver.lower()}{res}{end}")
                            exit()
                        return balance
                if self.service_solver.lower() == 'xevil':
                    try:
                        balance = float(userinfo)
                        if balance > 0:
                            return balance
                        if start_check:
                            return 0
                        print(f"{red}Dont have balance in {self.service_solver.lower()}{res}{end}")
                    except Exception:
                        if start_check:
                            return 0
                    exit()
                sleep(1)
        
        solver_session[self.service_solver].close()
        
        api_key = self.mkey if self.service_solver.lower() == 'multibot' else self.xkey
        sitekey = '6LdRZzspAAAAACwgump2Y7e8kAXOfF2ws9vLS-Rw'
        pageurl = 'https://hfaucet.com/doge/'
        type_captcha = 'userrecaptcha'

        url_solver = 'http://api.multibot.in' if self.service_solver.lower() == 'multibot' else 'http://goodxevilpay.pp.ua'
        
        if start_check:
            return get_balance()
        curr = 'tokens' if self.service_solver.lower() == 'multibot' else 'rub'
        self.captcha['balance'][self.service_solver] = get_balance()
        carousel_msg(f"Balance: {self.captcha['balance'][self.service_solver]} {curr}")
        id_task = get_id_task()
        result = get_solved()
        
        return result
    
    def mainbot(self):
        
        def view_ads(msg):
            nonlocal total_view_ads
            carousel_msg(msg)
            if 'Sorry, you must view the ad' in msg:
                max_views = 1
                search = re.search(r'(\d+)', msg)
                remaining = int(search.group(1))
            elif 'You need to view' in msg:
                max_views = int(msg.split('view')[1].strip().split(' ')[0])
                remaining = None
            views = 0
            param = 'press' if self.current_host == 'faucet.mom' else 'x1'
            while views < max_views:
                carousel_msg("Clicking on ads")
                url = f"https://{self.current_host}/doge/{param}.php"
                payload = {'email': self.current_email}
                r = self.curl('POST', url, payload)
                if remaining:
                    carousel_msg(f"Wait while I watch the ad for {remaining} minutes")
                    wait(remaining * 60)
                    r = self.curl('POST', url, payload)
                if r:
                    if 'successfully' in r.text:
                        views += 1
                        total_view_ads += 1
                        carousel_msg(f"Success add click view [ {views}/{max_views} ]")
                else:
                    print(r)
                sleep(0.1)
        
        def claim_faucet(box_id, amount):
            nonlocal total_claimed_box
            nonlocal total_collected
            nonlocal start_claim
            nonlocal end_claim
            nonlocal starting
            nonlocal finishedx
            nonlocal finishedy
            while True:
                carousel_msg("Caliming treasure chest")
                url = f"https://{self.current_host}/doge/openBox.php"
                payload = {'email': self.current_email,'box_id': box_id}
                r = self.curl('POST', url, payload)
                if r:
                    r = json.loads(r.text)
                    if 'remainingTime' in r:
                        carousel_msg(r['message'])
                        wait(r['remainingTime'])
                        continue
                    elif 'type' in r:
                        if 'error' in r['type']:
                            if 'view' in r['message']:
                                view_ads(r['message'])
                                continue
                            else:
                                print(r)
                        elif 'success' in r['type']:
                            msg_action("TREASURE CHEST")
                            print(f" {red}# {white}Box ID: {green}{box_id}{res}{end}")
                            print(f" {red}# {white}Reward: {green}{amount} satoshis doge{res}{end}")
                            print(f" {red}# {white}{r['message']}{res}{end}")
                            print(f" {red}# {white}Host: {celeste}{self.current_host.lower()}{res}{end}")
                            if self.current_host == 'hfaucet.com':
                                print(f" {red}# {white}Balance {self.service_solver.capitalize()}: {green}{self.captcha['balance'][self.service_solver]}{res}  -  [ {red}{self.captcha['count']['failed']}{res} / {green}{self.captcha['count']['spent']}{res} ]{end}")
                            if self.show_emails:
                                print(f" {red}# {white}Account: {yellow}{self.current_email}{res}{end}")
                            msg_line()
                            total_claimed_box += 1
                            total_collected += int(amount)
                            if starting is None:
                                starting = datetime.now()
                                finishedx = starting + timedelta(minutes=5) + timedelta(seconds=2)
                                if finishedy is None:
                                    finishedy = starting + timedelta(minutes=10) + timedelta(seconds=2)
                            if start_claim is None:
                                start_claim = get_time()
                            if self.current_email == self.list_emails[-1]:
                                end_claim = get_time()
                            return
                        else:
                            carousel_msg("Claim treasures chests failed")
                            print(r)
                    else:
                        print(r)
        
        def check_next_box():
            while True:
                url = f"https://{self.current_host}/doge/dashboard.php"
                r = self.curl('GET', url)
                if r:
                    soup = BeautifulSoup(r.text, 'html.parser')
                    total_boxes = soup.select('body > div.container.my-5 > div.row > div')
                    filtered_boxes = [box for box in total_boxes if box.select_one('p.gold-text') and box.select_one('img.img-fluid')]
                    if len(filtered_boxes) > 0:
                        for box in filtered_boxes:
                            gold_text = box.select_one('p.gold-text').text.strip()
                            if gold_text:
                                search = re.search(r'(\d+)', gold_text)
                                amount = int(search.group(1)) if search else None
                            else:
                                amount = None
                            claim_button = box.select_one('.claim-btn')
                            box_id = claim_button['data-id'] if claim_button else None
                            if (box_id is not None and box_id.isdigit() and
                                amount is not None and isinstance(amount, int)):
                                return box_id, amount
                            continue
                    return None, None
                else:
                    carousel_msg("Error getting treasures chests info")
                    wait(10)
        
        def login():
            self.sessions[self.current_host][self.current_email].close()
            while True:
                carousel_msg(f"Login with email: {self.current_email}")
                url = f"https://{self.current_host}/doge/confirm.php"
                if self.current_host == 'hfaucet.com':
                    captcha = self.solver()
                    self.captcha['count']['spent'] += 1
                    payload = {'email': self.current_email,'ref': '100000000000000', 'g-recaptcha-response': captcha}
                else:
                    payload = {'email': self.current_email,'ref': '100000000000000'}
                r = self.curl('POST', url, payload)
                if str(self.current_email) in r.text:
                    carousel_msg("Successfully login")
                    return
                else:
                    self.captcha['count']['failed'] += 1
                    for i, host in enumerate(self.list_hosts):
                        if host == self.current_host:
                            if i + 1 < len(self.list_hosts):
                                self.current_host = self.list_hosts[i + 1]
                            else:
                                self.current_host = self.list_hosts[0]
                            break
                    carousel_msg("Tryigin login again")
                    carousel_msg(f"Switching to host {self.current_host}")
                sleep(0.1)
        
        if self.start:
            self.start = False
            carousel_msg("Waiting for first claim")
            #wait(5 * 60)
        
        total_view_ads = 0
        total_claimed_box = 0
        total_collected = 0
        finishedy = None
        finishedx = None
        starting = None
        
        while True:
            start_claim = None
            end_claim = None
            for host in self.list_hosts:
                self.current_host = host
                if self.current_host == 'hfaucet.com' and finishedy is not None and datetime.now() >= finishedy:
                    finishedy = None
                for email in self.list_emails:
                    self.current_email = email
                    if (self.current_host != 'hfaucet.com' or 
                        self.current_host == 'hfaucet.com' and 
                        self.current_email == self.list_emails[0] and 
                        finishedy is None):
                        if self.sessions[self.current_host][self.current_email].cookies:
                            pass
                        else:
                            login()
                        box_id, amount = check_next_box()
                        if box_id is not None and amount is not None:
                            claim_faucet(box_id, amount)
                        else:
                            continue
                        if email == self.list_emails[-1]:
                            if self.show_information:
                                line = f"{celeste}="
                                collected = "{:.8f}".format(total_collected / 10**8)
                                print(line * 17 + "[ INFORMATION ] " + line * 17)
                                print(f" {yellow}Hosts{red}: {white}[ {self.list_hosts.index(self.current_host)+1} / {len(self.list_hosts)} ]{res}")
                                print(f" {yellow}Fp Emails{red}: {white}[ {len(self.list_emails)} ]{res}{end}")
                                print(f" {yellow}Claimed Box{red}: {white}[ {total_claimed_box} ]{res}")
                                print(f" {yellow}Visited Ads{red}: {white}[ {total_view_ads} ]{res}{end}")
                                print(f" {yellow}Collected{red}: {green}{collected}{white} Doge{res}{end}")
                                print(f" {yellow}Time{red}: {white}{start_claim}     {green}-{white}     {end_claim}{end}")
                                print(line * 50)
                                msg_line()
                            sleep(2)
                            break
                        else:
                            carousel_msg("Switching account")
                            sleep(1)
                if host == self.list_hosts[-1]:
                    carousel_msg("Success visited all hosts")
                    if datetime.now() >= finishedx:
                        remaining = 1
                    else:
                        remaining = max(1, (finishedx - datetime.now()).total_seconds())
                    remaining = max(1, int(remaining))
                    wait(remaining)
                    starting = None
                    finishedx = None
                    break
                else:
                    carousel_msg("Switching host")
                    
            self.update_list_emails(re_loading=True)
            self.update_list_host(re_loading=True)
                    
    def update_list_emails(self, re_loading):
        existing_emails = []
        try:
            with open('emails_faucetpay.txt', 'r') as f:
                existing_emails = [line.strip() for line in f if line.strip() and not line.strip().startswith('#')]
        except Exception:
            if re_loading:
                carousel_msg("Error reading emails")
                carousel_msg("Updating list emails skiped")
                return
        
        emails = []
        
        if not re_loading:
            while True:
                email = input(f"(press Enter to skip), {yellow}Email{red}:{res} ")
                if email == '' or email.isspace():
                    clean_screen()
                    msg_line()
                    print(f"{green}{sc_ver.center(50, ' ')}")
                    msg_line()
                    break
                elif email and '@' in email:
                    emails.append(email)
                else:
                    carousel_msg("Email not valid")

        carousel_msg("Updating list emails")
        existing_emails += emails
        
        if len(existing_emails) < 1:
            if not re_loading:
                print(f"{red}Not emails found{res}")
                exit()
            else:
                carousel_msg("Updating list emails skiped")
                return
        
        with open('emails_faucetpay.txt', 'w') as f:
            f.write('\n'.join(existing_emails))
        
        if not re_loading:
            banner()
        
        carousel_msg(f"Success updated list emails | N°: [ {len(existing_emails)} ]")
        
        unique_emails = []
        for email in existing_emails:
            if email not in unique_emails:
                unique_emails.append(email)
        self.list_emails = unique_emails

    def update_list_host(self, re_loading):
        carousel_msg("Updating list host")
        existing_host = []
        try:
            with open('host.txt', 'r') as f:
                existing_host = [line.strip() for line in f if line.strip() and not line.strip().startswith('#')]
        except Exception:
            print(f"{red}Error reading hosts{res}")
            if not re_loading:
                exit()
            else:
                carousel_msg("Updating list hosts skiped")
                return

        if len(existing_host) < 1:
            if not re_loading:
                print(f"{red}Not hosts found{res}")
                exit()
            else:
                carousel_msg("Updating list emails skiped")
                return
        
        carousel_msg(f"Success updated list hosts | N°: [ {len(existing_host)} ]")
        
        unique_hosts = []
        for host in existing_host:
            if host not in unique_hosts:
                unique_hosts.append(host)
        self.list_hosts = unique_hosts
        
    def config(self):
        
        def get_valid_user_agent():
            user_agent = ''
            while len(user_agent) < 10 or 'Mozilla' not in user_agent:
                user_agent = input(f"{yellow}Enter User-Agent{red}:{res} ")
            return user_agent.strip()
        
        def get_key_solver(service):
            api_key = ''
            while len(api_key) < 10:
                api_key = input(f"{yellow}Enter api-key {service}{red}:{res} ")
            return api_key.strip()
            
        def checking_balance_solver():
            banner()
            carousel_msg(f"Checking if available balance in {self.service_solver}")
            balance = self.solver(start_check=True)
            if balance is not None and balance > 0:
                curr = 'tokens' if self.service_solver.lower() == 'multibot' else 'rub'
                self.captcha['balance'][self.service_solver] = balance
                carousel_msg(f"Balance: {balance} {curr}")
                return
            carousel_msg(f"{red}Dont have balance in {self.service_solver}{res}")
            exit()
        
        try:
            with open('User_Agent', 'r') as f:
                user_agent = f.read().strip()
        except FileNotFoundError:
            user_agent = get_valid_user_agent()
            with open('User_Agent', 'w') as f:
                    f.write(user_agent)
        
        self.user_agent = user_agent
        
        options = ['Show emails', 'Show information']

        for option in options:
            opt = ''
            while opt not in ['y', 'n']:
                opt = input(f"{celeste}{option} (y/n):{res} ").lower().strip()
            if option == 'Show emails':
                self.show_emails = True if opt == 'y' else False
            elif option == 'Show information':
                self.show_information = True if opt == 'y' else False
        
        self.update_list_emails(re_loading=False)
        self.update_list_host(re_loading=False)
        
        self.current_host = self.list_hosts[0]
        self.current_email = self.list_emails[0]
        self.sessions = {
            host: {email: requests.Session() for email in self.list_emails}
            for host in self.list_hosts
        }
        
        option = input(f"{yellow}Select Solver Service{red}:{res}\n{white}1.- {celeste}Multibot\n{white}2.- {lila}Xevil\n\n{white}Input number: ")

        if option.isdigit() and 1 <= int(option) <= 2:
            if str(option) == "1":
                self.service_solver = "multibot"
                try:
                    with open('Api Multibot', 'r') as f:
                        self.mkey = f.read().strip()
                except Exception:
                    self.mkey = get_key_solver(self.service_solver)
                with open('Api Multibot', 'w') as f:
                    f.write(self.mkey)
                checking_balance_solver()
                    
            elif str(option) == "2":
                self.service_solver = "xevil"
                try:
                    with open('Api Xevil', 'r') as f:
                        self.xkey = f.read().strip()
                except Exception:
                    self.xkey = get_key_solver(self.service_solver)
                with open('Api Xevil', 'w') as f:
                    f.write(self.xkey)
                checking_balance_solver()
        else:
            print(f"{red}Invalid option")
            exit()
        banner()

bot = Bot()
bot.start = True
bot.show_emails = True
bot.show_information = True
bot.captcha = {
    'balance': {},
    'count': {
        'spent': 0,
        'failed': 0,
        'attemps': 0,
        't_attemps': 0
    }
}
banner()
bot.config()
bot.mainbot()
