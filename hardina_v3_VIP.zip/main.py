import re
import os
import sys
import json
import time
import requests
from time import sleep
from bs4 import BeautifulSoup
from urllib.parse import urlencode
from datetime import datetime
from json.decoder import JSONDecodeError
from random import randint, choice, uniform
from colorama import Fore, Back, Style, init
from requests.exceptions import RequestException, ConnectionError, Timeout

s = requests.Session()

init(autoreset=True)

sc_ver = 'HADIRNA v3'

end = "\033[K"
res = Style.RESET_ALL
red = Style.BRIGHT+Fore.RED
bg_red = Back.RED
white = Style.BRIGHT+Fore.WHITE
green = Style.BRIGHT+Fore.GREEN
yellow = Style.BRIGHT+Fore.YELLOW
colors = [Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN]

def clean_screen():
    os.system("clear" if os.name == "posix" else "cls")
    
def save_log(html, namefile):
    soup = BeautifulSoup(html.text, 'html.parser')
    body = soup.prettify()
    with open(f"{namefile}.html", "w", encoding="utf-8") as file:
        file.write(body)

class Bot:
    def __init__(self):
        self.host = 'hfaucet.com'
        self.service_solver = None
        self.count_captcha = {'spent': 0, 'failed': 0, 'attemps': 0, 't_attemps': 0}

    def curl(self, method, url, data=None):
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'conttent-type': 'application/x-www-form-urlencoded',
            'user-agent': self.user_agent
        }
        while True:
            try:
                r = s.request(method, url, headers=headers, data=data, timeout=10)
                if 200 <= r.status_code < 400:
                    return r
                elif r.status_code == 403:
                    self.carousel_msg("Access denied")
                    sleep(10)
                    return None
                elif 500 <= r.status_code < 600:
                    print(r.text)
                    self.carousel_msg(f"Server {self.host} down.")
                    return
                else:
                    self.carousel_msg(f"Unexpected response code: {r.status_code}")
                    return None
            except ConnectionError:
                self.carousel_msg(f"Reconnecting to {self.host}")
            except Timeout:
                self.carousel_msg("Too many requests")
            self.wait(10)

    def wait(self, x):
        for i in range(x, -1, -1):
            col = yellow if i%2 == 0 else white
            animation = "⫸" if i%2 == 0 else "⫸⫸"
            m, s = divmod(i, 60)
            t = f"[00:{m:02}:{s:02}]"
            sys.stdout.write(f"\r  {white}Please wait {col}{t} {animation}{res}{end}\r")
            sys.stdout.flush()
            sleep(1)

    def carousel_msg(self, message):
        def first_part(message, wait):
            animated_message = message.center(48)
            msg_effect = ""
            for i in range(len(animated_message) - 1):
                msg_effect += animated_message[i]
                sys.stdout.write(f"\r {msg_effect}{res} {end}")
                sys.stdout.flush()
                sleep(0.03)
            if wait:
                sleep(1)

        msg_effect = message[:47]
        wait = True if len(message) <= 47 else False
        first_part(msg_effect, wait)
        if len(message) > 47:
            for i in range(50, len(message)):
                msg_effect = msg_effect[1:] + message[i]
                if i > 1:
                    sys.stdout.write(f"\r {msg_effect} {res}{end}")
                    sys.stdout.flush()
                sleep(0.1)
        sleep(1)
        sys.stdout.write(f"\r{res}{end}\r")
        sys.stdout.flush()

    def msg_line(self):
        print(f"{green}{'━' * 50}")

    def msg_action(self, action):
        now = datetime.now()
        now = now.strftime("%d/%b/%Y %H:%M:%S")
        total_length = len(action) + len(now) + 5
        space_count = 50 - total_length
        msg = f"[{action.upper()}] {now}{' ' * space_count}"
        print(f"{bg_red} {white}{msg}{res}{red}⫸{res}{end}")

    def write_file(self, data):
        with open('config.json', 'w') as f:
            json.dump(data, f, indent=4)

    def formating(self, num):
        value = float(num) / 10**8
        return "{:.8f}".format(value)

    def mainbot(self):
        
        def login():
            while True:
                self.carousel_msg("Login proccessing...")
                url = f"https://{self.host}/doge/confirm.php"
                payload = {'email': self.email,'ref': '10000'}
                r = self.curl('POST', url, payload)
                if str(self.email) in r.text:
                    self.carousel_msg("Successfully login")
                    return
                else:
                    self.carousel_msg("Tryigin login again")
                    if self.host == 'hadirna':
                        self.host = 'hfaucet'
                    else:
                        self.host = 'hadirna'
                self.wait(2 * 60)
        
        login()
        print(f"\n{bg_red}{white} ๏ {res} {yellow}〔 EMAIL 〕.: {res}{self.email}{end}")
        print(f"{res}{end}")
        self.msg_line()
        #self.wait(5 * 60)
        while True:
            url = f"https://{self.host}/doge/dashboard.php"
            r = self.curl('GET', url)
            if r:
                soup = BeautifulSoup(r.text, 'html.parser')
                total_boxes = soup.select('body > div.container.my-5 > div.row > div')
                filtered_boxes = [box for box in total_boxes if box.select_one('p.gold-text') and box.select_one('img.img-fluid')]
                if len(filtered_boxes) > 0:
                    for box in filtered_boxes:
                        gold_text = box.select_one('p.gold-text').text.strip()
                        claim_button = box.select_one('.claim-btn')
                        box_id = claim_button['data-id'] if claim_button else None
                        if box_id is not None and box_id.isdigit():
                            self.carousel_msg("Caliming treasure chest")
                            url = f"https://{self.host}/doge/openBox.php"
                            payload = {'email': self.email,'box_id': box_id}
                            r = self.curl('POST', url, payload)
                            if r:
                                r = json.loads(r.text)
                                if 'type' in r:
                                    if 'success' in r['type']:
                                        self.msg_action("TREASURE CHEST")
                                        print(f" {red}# {white}Box ID: {green}{box_id}{res}{end}")
                                        print(f" {red}# {white}Reward: {green}{gold_text}s doge{res}{end}")
                                        print(f" {red}# {white}{r['message']}{res}{end}")
                                        self.msg_line()
                                        self.wait(5 * 60)
                                        break
                                    elif 'error' in r['type'] and 'view' in r['message']:
                                        self.carousel_msg(r['message'])
                                        max_views = int(r['message'].split('view')[1].strip().split(' ')[0])
                                        for i in range(max_views):
                                            self.carousel_msg("Clicking on ads")
                                            url = f"https://{self.host}/doge/press.php"
                                            payload = {'email': self.email}
                                            r = self.curl('POST', url, payload)
                                            if r:
                                                if 'successfully' in r.text:
                                                    self.carousel_msg(f"Success add click view [ {i+1}/{max_views} ]")
                                        continue
                                    else:
                                        print(r)
                                else:
                                    print(r)
                            else:
                                self.carousel_msg("Claim treasures chests failed")
                                self.wait(10)
                else:
                    self.carousel_msg("No more treasures available, try later moment")
                    self.wait(60 * 60)
                    login()
            else:
                self.carousel_msg("Error getting treasures chests info")
                self.wait(10)
    
    def config(self):
        
        def fill_config(key):
            while key not in config or len(config[key]) < 5:
                config[key] = input(f"\n{yellow}{key}{red}:{res} ")
            return

        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            config = {}
        except json.JSONDecodeError:
            print(f"{red}Check your config file")
            exit()

        keywords = ['Email', 'User-Agent']

        for key in keywords:
            fill_config(key)

        os.system("clear" if os.name == "posix" else "cls")

        self.write_file(config)
        self.email = config['Email']
        self.user_agent = config['User-Agent']

bot = Bot()
bot.config()

clean_screen()
bot.msg_line()
print(f"{green}{sc_ver.center(50, ' ')}")
bot.msg_line()

bot.mainbot()