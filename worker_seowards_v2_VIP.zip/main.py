import re
import os
import sys
import json
import html
import base64
import requests
from time import sleep
from bs4 import BeautifulSoup
from datetime import datetime
from json.decoder import JSONDecodeError
from random import randint, choice, uniform
from colorama import Fore, Back, Style, init
from requests.exceptions import RequestException, ConnectionError, Timeout

s = requests.Session()

init(autoreset=True)

sc_ver = "WORKER SEOWARDS"
host = 'worker.seowards.com'

end = "\033[K"
res = Style.RESET_ALL
red = Style.BRIGHT+Fore.RED
bg_red = Back.RED
white = Style.BRIGHT+Fore.WHITE
green = Style.BRIGHT+Fore.GREEN
yellow = Style.BRIGHT+Fore.YELLOW
colors = [Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN]

def clean_screen():
    os.system("clear" if os.name == "posix" else "cls")

class Bot:

    def curl(self, method, url, data=None):
        headers = {
            'user-agent': self.user_agent
        }
        while True:
            try:
                r = s.request(method, url, headers=headers, data=data, timeout=10)
                if r.status_code == 200:
                    return r
                elif r.status_code == 403:
                    self.carousel_msg("Access denied")
                    return None
                elif 500 <= r.status_code < 600:
                    self.carousel_msg(f"Server {host} down.")
                else:
                    
                    print(url)
                    print(data)
                    self.carousel_msg(f"Unexpected response code: {r.status_code}")
                    return None
            except ConnectionError:
                self.carousel_msg(f"Reconnecting to {host}")
            except Timeout:
                self.carousel_msg("Too many requests")
            self.wait(10)

    def wait(self, x):
        for i in range(x, -1, -1):
            col = yellow if i%2 == 0 else white
            animation = "⫸" if i%2 == 0 else "⫸⫸"
            m, s = divmod(i, 60)
            t = f"[00:{m:02}:{s:02}]"
            sys.stdout.write(f"\r  {white}Please wait {col}{t} {animation}{res}{end}\r")
            sys.stdout.flush()
            sleep(1)

    def carousel_msg(self, message):
        def first_part(message, wait):
            animated_message = message.center(48)
            msg_effect = ""
            for i in range(len(animated_message) - 1):
                msg_effect += animated_message[i]
                sys.stdout.write(f"\r {msg_effect}{res} {end}")
                sys.stdout.flush()
                sleep(0.03)
            if wait:
                sleep(1)

        msg_effect = message[:47]
        wait = True if len(message) <= 47 else False
        first_part(msg_effect, wait)
        if len(message) > 47:
            for i in range(50, len(message)):
                msg_effect = msg_effect[1:] + message[i]
                if i > 1:
                    sys.stdout.write(f"\r {msg_effect} {res}{end}")
                    sys.stdout.flush()
                sleep(0.1)
        sleep(1)
        sys.stdout.write(f"\r{res}{end}\r")
        sys.stdout.flush()

    def msg_line(self):
        print(f"{green}{'━' * 50}")

    def msg_action(self, action):
        now = datetime.now()
        now = now.strftime("%d/%b/%Y %H:%M:%S")
        total_length = len(action) + len(now) + 5
        space_count = 50 - total_length
        msg = f"[{action.upper()}] {now}{' ' * space_count}"
        print(f"{bg_red} {white}{msg}{res}{red}⫸{res}{end}")

    def claim(self):
        def get_user_id():  
            self.carousel_msg("Getting user id")
            while True:
                url = f"https://{host}/dashboard/earn-point-ads.php"
                r = self.curl('GET', url)
                if r:
                    soup = BeautifulSoup(r.text, 'html.parser')
                    user_id = None
                    scripts = soup.find_all('script')
                    for script in scripts:
                        if 'scratch-card-id' in str(script):
                            match = re.search(r'let userId = "(\d+)";', str(script))
                            if match and match.group(1):
                                user_id = match.group(1)
                            break
                    if user_id is not None:
                        self.carousel_msg(f"Success found user_id: {user_id}")
                        return user_id
                    else:
                        self.carousel_msg("User_id not found")
        
        def get_json(url, section):
            self.carousel_msg(f"Go to {section} section")
            r = self.curl('GET', url)
            try:
                r = json.loads(r.text)
                return r
            except Exception as e:
                self.carousel_msg(f"Error: {e}")
            return None
        
        def transactions():
            url = f"https://{host}/dashboard/transactions"
            transactions = []
            while True:
                r = self.curl('GET', url)
                if r:
                    soup = BeautifulSoup(r.text, 'html.parser')
                    rows = soup.select('tbody tr')
                    if rows:
                        for row in rows:
                            transaction = {
                                'id': row.select_one('.sorting_1').text.strip(),
                                'description': row.select_one('td:nth-of-type(3)').text.strip(),
                                'points': row.select_one('td:nth-of-type(4)').text.strip(),
                                'date': row.select_one('td:nth-of-type(5)').text.strip(),
                                'user': row.select_one('td:nth-of-type(6)').text.strip(),
                                'status': row.select_one('.badge-success').text.strip() if row.select_one('.badge-success') else None
                            }
                            transactions.append(transaction)
                        return transactions
                sleep(1)
        
        def daily(user_id):
            while True:
                url = f"https://{host}/admin/controller/daily-checkin.php"
                payload = {'userID': user_id}
                r = self.curl('POST', url, payload)
                if r:
                    r = json.loads(r.text)
                    if 'error_description' in r:
                        self.carousel_msg(r['error_description'])
                        if 'credited' in r['error_description'].lower():
                            history_rewards = transactions()
                            for i in range(len(history_rewards)):
                                if history_rewards[i]['description']:
                                    if 'registro diario' in history_rewards[i]['description']:
                                        if history_rewards[i]['points']:
                                            earn = history_rewards[i]['points']
                                            v = self.data_account()
                                            self.msg_action("DAILY")
                                            print(f" {red}# {white}Reward: {green}{earn}{res}{end}")
                                            print(f" {red}# {white}Points: {green}{v['points']}{res}{end}")
                                            self.msg_line()
                                            break
                        break
                else:
                    self.carousel_msg("Error getting dayli claim")
                sleep(2)
        
        def scratch_ads_video(user_id, section):
            while True:
                param = 'scratch-cards' if section == 'scratch' else 'websites' if section == 'ad' else 'videos'
                name_section = 'scratch' if section == 'scratch' else 'ads' if section == 'ad' else 'videos'
                while True:
                    url = f"https://{host}/admin/api/v3/{param}.php?user_id={user_id}"
                    jsn = get_json(url, section)
                    if jsn is not None:
                        break
                    self.carousel_msg(f"Error getting section {name_section}")
                    self.wait(10)
            
                if 'status' in jsn and jsn['status']:
                    if 'data' in jsn:
                        if len(jsn['data']) > 0:
                            _id = jsn['data'][0]['id']
                            title = html.unescape(jsn['data'][0]['title'])
                            points = jsn['data'][0]['point']
                            reward_by = 'scratch'
                            if section in ['ad', 'video']:
                                url_key = 'youtube_url' if section == 'video' else 'website_url'
                                url = html.unescape(jsn['data'][0][url_key])
                                timer = jsn['data'][0]['timer']
                                if section == 'ad':
                                    param = 'web'
                                    reward_by = 'website'
                                    self.carousel_msg(f"View ads, {title}")
                                else:
                                    param = 'video'
                                    reward_by = 'youtube'
                                    id_yt = url.split('watch?v=')[1]
                                
                                url = f"https://{host}/dashboard/{param}-details.php?id={_id}&title={title}&url={url}&timer={timer}"
                                r = self.curl('GET', url)
                                if section == 'video':
                                    self.carousel_msg(f"Playing video, {title}")
                                    while True:
                                        view_youtube = self.curl('GET', f"https://www.youtube.com/embed/{id_yt}?autoplay=1")
                                        if view_youtube:
                                            break
                                        else:
                                            self.carousel_msg(f"Error open video: {title}")
                                            break
                                        sleep(2)
                                self.wait(int(timer) + randint(2,5))
                            else:
                                self.wait(randint(26,30))
                            
                            url = f"https://{host}/admin/api/v3/add-reward-points.php"
                            payload = {
                                'user_id': user_id,
                                'id': _id,
                                'reward_by': reward_by
                            }
                            while True:
                                r = self.curl('POST', url, payload)
                                if r:
                                    break
                                sleep(2)
                            r = json.loads(r.text)
                            if 'status' in r and r['status']:
                                earn = None
                                if r['message']:
                                    try:
                                        earn = r['message'].split('Puntos')[0]
                                        earn = int(earn)
                                    except Exception:
                                        earn = points
                                else:
                                    earn = points
                                
                                v = self.data_account()
                                self.msg_action(f"{section.upper()}S")
                                print(f" {red}# {white}Reward: {green}{earn}{res}{end}")
                                print(f" {red}# {white}Points: {green}{v['points']}{res}{end}")
                                if section in ['ad', 'video']:
                                    print(f" {red}# {white}Title: {res}{title}{end}")
                                self.msg_line()
                            elif 'status' in r and not r['status']:
                                self.carousel_msg(f"Claim {section} failed")
                            else:
                                self.carousel_msg(str(r))
                        else:
                            self.carousel_msg(f"{section.capitalize()}s not available")
                            break
                    else:
                        self.carousel_msg(f"Error getting data claim {section}")
                        break
                elif 'status' in jsn and not jsn['status']:
                    self.carousel_msg(f"No more {section}s available, try later moment")
                    break
                else:
                    print(jsn)
    
        self.login()
        user_id = get_user_id()
        v = self.data_account()
        print(f"\n{bg_red}{white} ๏ {res} {yellow}〔 USERNAME 〕..........: {res}{v['username']}{end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 POINTS 〕............: {res}{v['points']}{end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 POINTS REDEEMED 〕...: {res}{v['points_redeemed']}{end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 TOTAL EARNINGS 〕....: {res}{v['earnings']}{end}")
        print(f"{bg_red}{white} ๏ {res} {yellow}〔 REFFERALS 〕.........: {res}{v['refferals']}{end}")
        print(f"{res}{end}")
        self.msg_line()
        while True:
            daily(user_id)
            for section in ['scratch', 'ad', 'video']:
                scratch_ads_video(user_id, section)
            self.wait(30 * 60)
            self.login()
            sleep(2)
            user_id = get_user_id()

    def write_file(self, data):
        with open('config.json', 'w') as f:
            json.dump(data, f, indent=4)

    def data_account(self):
        while True:
            self.carousel_msg("Getting user info")
            url = f"https://{host}/dashboard/index"
            r = self.curl('GET', url)
            v = {}
            soup = BeautifulSoup(r.text, 'html.parser')
            v['username'] = soup.select_one('#main-wrapper > div.deznav > div > div.main-profile > h5')
            v['points'] = soup.select_one('#main-wrapper > div.content-body > div > div:nth-child(2) > div > div > div:nth-child(1) > div > div > div > div > h3')
            v['earnings'] = soup.select_one('#main-wrapper > div.content-body > div > div:nth-child(2) > div > div > div:nth-child(2) > div > div > div > div > h3')
            v['points_redeemed'] = soup.select_one('#main-wrapper > div.content-body > div > div:nth-child(2) > div > div > div:nth-child(3) > div > div > div > div > h3')
            v['refferals'] = soup.select_one('#main-wrapper > div.content-body > div > div:nth-child(2) > div > div > div:nth-child(4) > div > div > div > div > h3')
            keywords = ['username', 'points', 'earnings', 'points_redeemed', 'refferals']
            for key in keywords:
                if v[key] is not None:
                    v[key] = v[key].text.strip()
                else:
                    self.carousel_msg("Error getting user info")
                    continue
            return v

    def login(self):
        while True:
            s.close()
            self.carousel_msg("Login processing...")
            while True:
                url = f"https://{host}/dashboard/login.php"
                r = self.curl('GET', url)
                soup = BeautifulSoup(r.text, 'html.parser')
                token_auth = soup.find('input', {'name': 'authenticity_token'})['value']
                if token_auth:
                    url = f"https://{host}/dashboard/login.php"
                    payload = {
                        'authenticity_token': token_auth,
                        'user_username': self.email,
                        'user_password': self.password
                    }
                    r = self.curl('POST', url, payload)
                    soup = BeautifulSoup(r.text, 'html.parser')
                    if 'cerrar sesion' in r.text.lower():
                        self.carousel_msg("Successfully Login")
                        return
                    else:
                        self.carousel_msg("Login failed")
                    self.wait(10)
                break

    def config(self):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            config = {}
        except json.JSONDecodeError:
            print(f"{red}Check your config file")
            exit()

        keywords = ['Email', 'Password', 'User-Agent']

        for key in keywords:
            while key not in config or len(config[key]) < 5:
                config[key] = input(f"\n{yellow}{key}{red}:{res} ")

        self.write_file(config)
        self.email = config['Email']
        self.password = config['Password']
        self.user_agent = config['User-Agent']

bot = Bot()
bot.config()

clean_screen()
bot.msg_line()
print(f"{green}{sc_ver.center(50, ' ')}")
bot.msg_line()

bot.claim()
