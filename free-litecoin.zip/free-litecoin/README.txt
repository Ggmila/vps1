     #File Written By ___ixteen

#Hello Everyone This Is A file Directions Of Use:
1. Get The Cookie
2. Get The UserAgent
3. Get The Accept Language

#Run Script And Paste The Values In Their Respective Positions
#Programs Are Illegal or Against The Law Run At your Own Risk
#Info ->
 -  Website/Faucet: https://free-litecoin.com/login?referer=2105010
 -  Tutorial: https://t.me/sixteencrypto_bot and command tutorials
 -  Writer: t.me/s_ixteen

#Enjoy...
