// popup.js

// Mengambil URL tab yang aktif
chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  const tabUrl = tabs[0].url;

  // Mengambil cookies
  chrome.runtime.sendMessage({ action: 'getCookies', url: tabUrl }, function(response) {
    document.getElementById('cookies').value = response.cookies;
  });

  // Mengambil User-Agent
  chrome.runtime.sendMessage({ action: 'getUserAgent' }, function(response) {
    document.getElementById('userAgent').value = response.userAgent;
  });
});

// Fungsi untuk menyalin isi dari sebuah textarea dan mengubah teks tombol
function copyToClipboard(elementId, buttonId) {
  const textArea = document.getElementById(elementId); // Ambil elemen textarea berdasarkan ID
  const button = document.getElementById(buttonId); // Ambil tombol berdasarkan ID

  if (textArea) {
    textArea.select(); // Pilih teks dalam textarea
    document.execCommand('copy'); // Salin teks ke clipboard

    // Ubah teks tombol setelah salin
    if (button) {
      button.textContent = buttonId === 'copyCookies' ? 'Cookies Copied' : 'User-Agent Copied'; // Ubah teks tombol berdasarkan ID tombol
      setTimeout(() => {
        button.textContent = buttonId === 'copyCookies' ? 'Copy Cookies' : 'Copy User-Agent'; // Kembalikan teks tombol setelah beberapa detik
      }, 2000); // Waktu tunggu 2 detik sebelum mengembalikan teks tombol
    }
    //alert('Copied to clipboard!');
  }
}

// Event listener untuk tombol Copy Cookies
document.getElementById('copyCookies').addEventListener('click', function() {
  copyToClipboard('cookies', 'copyCookies'); // Menyalin cookies dan mengubah tombol
});

// Event listener untuk tombol Copy User-Agent
document.getElementById('copyUserAgent').addEventListener('click', function() {
  copyToClipboard('userAgent', 'copyUserAgent'); // Menyalin User-Agent dan mengubah tombol
});
