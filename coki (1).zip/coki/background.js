// background.js

// Mengambil cookie dan menggabungkannya menjadi satu string
async function getCookies(tabUrl) {
  let cookies = await chrome.cookies.getAll({ url: tabUrl });
  let cookieString = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
  return cookieString;
}

// Mendapatkan User-Agent
function getUserAgent() {
  return navigator.userAgent;
}

// Menyediakan API untuk popup mengambil data
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getCookies') {
    getCookies(message.url).then(cookieString => {
      sendResponse({ cookies: cookieString });
    });
  } else if (message.action === 'getUserAgent') {
    sendResponse({ userAgent: getUserAgent() });
  }
  return true; // Untuk menjalankan response asynchronous
});
